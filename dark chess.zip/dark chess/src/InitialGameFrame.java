import view.ChessGameFrame;
import view2.ChessGameFrame2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;

public class InitialGameFrame extends JFrame {
    public static int frameIndex = 0;
    public static InitialGameFrame initial;
    public final int WIDTH;
    public final int HEIGHT;
    public final Icon defaultIcon = new ImageIcon("resource/image/鼠标指向前.jpg");
    public final Icon enterIcon = new ImageIcon("resource/image/指向后.jpg");
    public final Icon pressedIcon = new ImageIcon("resource/image/点击后.jpg");


    public InitialGameFrame(int width, int height) {
        WIDTH = width;
        HEIGHT = height;
        setTitle("初始界面");

        //加入背景图片
        ImageIcon img = new ImageIcon("resource/image/背景2.jpeg");//这是背景图片
        img.setImage(img.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT));
        JLabel imgLabel = new JLabel(img);//将背景图放在标签里。
        getLayeredPane().add(imgLabel, Integer.valueOf(Integer.MIN_VALUE));//注意这里是关键，将背景标签添加到jfram的LayeredPane面板里。
        imgLabel.setBounds(0, 0, WIDTH, HEIGHT);//设置背景标签的位置
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        ((JPanel) cp).setOpaque(false);

        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null); // Center the window.
        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置程序关闭按键，如果点击右上方的叉就游戏全部关闭了
        //setDefaultCloseOperation(ClickController.n);
        setLayout(null);

        addLabel();
        addAIButton();
        addPeopleButton();


    }


    private void addLabel() {
        JLabel initalGame = new JLabel("开始游戏");
        initalGame.setLocation(WIDTH / 4+87, HEIGHT / 3 - 95);
        initalGame.setSize(250, 60);
        initalGame.setFont(new Font("Rock", Font.BOLD, 35));
        add(initalGame);
    }


    private void addAIButton() {
        JButton button = new JButton("人机对战模式");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);

        button.setLocation(WIDTH  / 4+17, HEIGHT / 3);
        button.setSize(280, 60);
        button.setFont(new Font("Rock", Font.BOLD, 27));
        add(button);

        //加入鼠标监听
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
                ChessGameFrame2.CGFFF = ChessGameFrame2.newgame();
                initial.setVisible(false);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

    private void addPeopleButton() {
        JButton button = new JButton("双人对战模式");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);


        button.setLocation(WIDTH / 4+17, HEIGHT * 2 / 3-20-10);
        button.setSize(280, 60);
        button.setFont(new Font("Rock", Font.BOLD, 27));
        add(button);

        //加入鼠标监听
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //有时间了可以做得更好
                //JOptionPane.showMessageDialog(null, "达咩~不要点我哟~");
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
                ChessGameFrame.CGFFF = ChessGameFrame.newgame();
                initial.setVisible(false);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

}
