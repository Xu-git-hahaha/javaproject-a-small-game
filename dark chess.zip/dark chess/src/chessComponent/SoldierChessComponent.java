package chessComponent;

import Level.Level;
import controller.ClickController;
import model.ChessColor;
import model.ChessboardPoint;

import java.awt.*;

public class SoldierChessComponent extends ChessComponent {

    public SoldierChessComponent(ChessboardPoint chessboardPoint, Point location, ChessColor chessColor, ClickController clickController, int size,Boolean isReversal) {
        super(chessboardPoint, location, chessColor, clickController, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "兵";
        } else {
            name = "卒";
        }
    }
    private Level level = Level.Bing;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Bing__R"+reversalStr();
        }else return "Bing__B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}
