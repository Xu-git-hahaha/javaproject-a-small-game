package chessComponent;

import Level.Level;
import controller.ClickController;
import model.ChessColor;
import model.ChessboardPoint;

import java.awt.*;

/**
 * 表示黑红车
 */
public class MaCC extends ChessComponent {

    public MaCC(ChessboardPoint chessboardPoint, Point location, ChessColor chessColor, ClickController clickController, int size,Boolean isReversal) {
        super(chessboardPoint, location, chessColor, clickController, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "傌";
        } else {
            name = "馬";
        }
    }
    private Level level = Level.Ma;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Ma____R"+reversalStr();
        }else return "Ma____B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}
