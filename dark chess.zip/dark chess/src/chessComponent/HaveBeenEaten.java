package chessComponent;

public class HaveBeenEaten {
}
