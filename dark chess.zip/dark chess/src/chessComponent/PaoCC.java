package chessComponent;

import Level.Level;
import controller.ClickController;
import model.ChessColor;
import model.ChessboardPoint;

import java.awt.*;

/**
 * 表示黑红车
 */
public class PaoCC extends ChessComponent {

    public PaoCC(ChessboardPoint chessboardPoint, Point location, ChessColor chessColor, ClickController clickController, int size,Boolean isReversal) {
        super(chessboardPoint, location, chessColor, clickController, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "炮";
        } else {
            name = "砲";
        }
    }
    private Level level = Level.Pao;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Pao___R"+reversalStr();
        }else return "Pao___B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}

