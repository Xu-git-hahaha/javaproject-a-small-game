package chessComponent;

import Level.Level;
import controller.ClickController;
import model.ChessColor;
import model.ChessboardPoint;

import java.awt.*;

/**
 * 表示黑红车
 */
public class JiangCC extends ChessComponent {

    public JiangCC(ChessboardPoint chessboardPoint, Point location, ChessColor chessColor, ClickController clickController, int size,Boolean isReversal) {
        super(chessboardPoint, location, chessColor, clickController, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "帥";
        } else {
            name = "將";
        }
    }
    private Level level = Level.Jiang;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Jiang_R"+reversalStr();
        }else return "Jiang_B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}
