package chessComponent;

import Level.Level;
import controller.ClickController;
import model.ChessColor;
import model.ChessboardPoint;

import java.awt.*;

/**
 * 表示黑红车
 */
public class XiangCC extends ChessComponent {

    public XiangCC(ChessboardPoint chessboardPoint, Point location, ChessColor chessColor, ClickController clickController, int size,Boolean isReversal) {
        super(chessboardPoint, location, chessColor, clickController, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "相";
        } else {
            name = "象";
        }
    }
    private Level level = Level.Xiang;

    @Override
    public Level getLevel() {
        return level;
    }

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Xiang_R"+reversalStr();
        }else return "Xiang_B"+reversalStr();
    }
}

