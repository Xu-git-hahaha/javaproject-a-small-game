package chessComponent;

import Level.Level;
import controller.ClickController;
import model.ChessColor;
import model.ChessboardPoint;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * 表示黑红车
 */
public class ChariotChessComponent extends ChessComponent {

    public ChariotChessComponent(ChessboardPoint chessboardPoint, Point location, ChessColor chessColor, ClickController clickController, int size,Boolean isReversal) {
        super(chessboardPoint, location, chessColor, clickController, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "俥";
        } else {
            name = "車";
        }
    }

    public Level getLevel() {
        return level;
    }

    private Level level = Level.Che;
    public void loadResource() throws IOException {
        if (B_origin == null) {
            B_origin = ImageIO.read(new File("resource/image/棋子未指向.jpg"));
        }

        if (B_entered == null) {
            B_entered = ImageIO.read(new File("resource/image/棋子已指向.jpg"));
        }
        if (R_origin == null) {
            R_origin = ImageIO.read(new File("resource/image/棋子未指向.jpg"));
        }

        if (R_entered == null) {
            R_entered = ImageIO.read(new File("resource/image/棋子已指向.jpg"));
        }
    }

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Che___R"+reversalStr();
        }else return "Che___B"+reversalStr();
    }
}
