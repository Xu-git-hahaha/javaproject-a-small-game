package listener;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class CustomMouseListener implements MouseListener {
    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
    //    button.setVerticalTextPosition(SwingConstants.CENTER);
     //   button.setHorizontalTextPosition(SwingConstants.CENTER);
    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
