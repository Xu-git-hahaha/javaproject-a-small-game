package chessComponent2;

import Level.Level;
import controller2.ClickController2;
import model2.ChessColor;
import model2.ChessboardPoint2;

import java.awt.*;

/**
 * 表示黑红车
 */
public class JiangCC2 extends ChessComponent22 {

    public JiangCC2(ChessboardPoint2 chessboardPoint2, Point location, ChessColor chessColor, ClickController2 clickController2, int size, Boolean isReversal) {
        super(chessboardPoint2, location, chessColor, clickController2, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "帥";
        } else {
            name = "將";
        }
    }
    private Level level = Level.Jiang;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Jiang_R"+reversalStr();
        }else return "Jiang_B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}
