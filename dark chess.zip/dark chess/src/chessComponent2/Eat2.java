package chessComponent2;

import Level.Level;

public class Eat2 {
    public boolean canEat(Level a, Level b){
        switch (a){
            case Bing :
                if(b == Level.Bing || b == Level.Jiang){
                    return true;
                } else {
                    return false;
                }
            case Ma:
                if(b == Level.Bing || b == Level.Ma || b == Level.Pao){
                    return true;
                } else {
                    return false;
                }
            case Che:
                if(b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che){
                    return true;
                } else {
                    return false;
                }
            case Xiang:
                if(b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang){
                    return true;
                } else {
                    return false;
                }
            case Shi:
                if(b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi){
                    return true;
                } else {
                    return false;
                }
            case Jiang:
                if(b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi || b == Level.Jiang){
                    return true;
                } else {
                    return false;
                }
            case Pao:
                return true;
            default:
                return false;
        }
    }
}
