package chessComponent2;

import Level.Level;
import controller2.ClickController2;
import model2.ChessColor;
import model2.ChessboardPoint2;

import java.awt.*;

/**
 * 表示黑红车
 */
public class XiangCC2 extends ChessComponent22 {

    public XiangCC2(ChessboardPoint2 chessboardPoint2, Point location, ChessColor chessColor, ClickController2 clickController2, int size, Boolean isReversal) {
        super(chessboardPoint2, location, chessColor, clickController2, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "相";
        } else {
            name = "象";
        }
    }
    private Level level = Level.Xiang;

    @Override
    public Level getLevel() {
        return level;
    }

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Xiang_R"+reversalStr();
        }else return "Xiang_B"+reversalStr();
    }
}

