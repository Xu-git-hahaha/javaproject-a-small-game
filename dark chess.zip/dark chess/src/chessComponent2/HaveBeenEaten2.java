package chessComponent2;

public class HaveBeenEaten2 {
}
