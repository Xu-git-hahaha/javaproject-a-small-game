package chessComponent2;

import Level.Level;
import controller2.ClickController2;
import model2.ChessColor;
import model2.ChessboardPoint2;

import java.awt.*;

/**
 * 表示黑红车
 */
public class MaCC2 extends ChessComponent22 {

    public MaCC2(ChessboardPoint2 chessboardPoint2, Point location, ChessColor chessColor, ClickController2 clickController2, int size, Boolean isReversal) {
        super(chessboardPoint2, location, chessColor, clickController2, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "傌";
        } else {
            name = "馬";
        }
    }
    private Level level = Level.Ma;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Ma____R"+reversalStr();
        }else return "Ma____B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}
