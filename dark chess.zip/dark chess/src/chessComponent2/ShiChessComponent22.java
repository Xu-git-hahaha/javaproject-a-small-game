package chessComponent2;

import Level.Level;
import controller2.ClickController2;
import model2.ChessColor;
import model2.ChessboardPoint2;

import java.awt.*;
import java.io.IOException;

public class ShiChessComponent22 extends ChessComponent22 {
    /**
     * 黑象和白象的图片，static使得其可以被所有象对象共享
     * <br>
     * FIXME: 需要特别注意此处加载的图片是没有背景底色的！！！
     */

    /**
     * 象棋子对象自身的图片，是上面两种中的一种
     */
//    private Image BishopImage;
    /**
     * 读取加载象棋子的图片
     *
     * @throws IOException
     */
    public ShiChessComponent22(ChessboardPoint2 chessboardPoint2, Point location, ChessColor chessColor, ClickController2 clickController2, int size, Boolean isReversal) {
        super(chessboardPoint2, location, chessColor, clickController2, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "士";
        } else {
            name = "仕";
        }
    }
    private Level level = Level.Shi;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Shi___R"+reversalStr();
        }else return "Shi___B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}
