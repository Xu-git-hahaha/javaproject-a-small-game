package chessComponent2;

import Level.Level;
import controller2.ClickController2;
import model2.ChessboardPoint2;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * 这个类表示棋盘上的空棋子的格子
 */
public class EmptySlotComponent22 extends SquareComponent2 {
    protected static Image SquareDefaultImage;

    public EmptySlotComponent22(ChessboardPoint2 chessboardPoint2, Point location, ClickController2 listener, int size, Boolean isReversal) {
     //   super(chessboardPoint, location, ChessColor.NONE, listener, size);
        super(chessboardPoint2, location, null, listener, size,isReversal);
        try {
            SquareDefaultImage = ImageIO.read(new File("resource/image/没有棋子的图.jpeg"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(SquareDefaultImage,0,0,getWidth(),getHeight(),this);

    }
    public Level level = Level.Blank;

    @Override
    public Level getLevel() {
        return level;
    }

    @Override
    public boolean canMoveTo(SquareComponent2[][] chessboard, ChessboardPoint2 destination) {
        return false;
    }

    @Override
    public String toString() {
        return "________";
    }
//    @Override
//    public String toString() {
//        if (getChessColor()==ChessColor.RED){
//            return "Che_R"+reversalStr();
//        }else return "Che_B"+reversalStr();
//    }

}
