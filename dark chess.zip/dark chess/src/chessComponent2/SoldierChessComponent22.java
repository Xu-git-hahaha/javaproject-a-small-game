package chessComponent2;

import Level.Level;
import controller2.ClickController2;
import model2.ChessColor;
import model2.ChessboardPoint2;

import java.awt.*;

public class SoldierChessComponent22 extends ChessComponent22 {

    public SoldierChessComponent22(ChessboardPoint2 chessboardPoint2, Point location, ChessColor chessColor, ClickController2 clickController2, int size, Boolean isReversal) {
        super(chessboardPoint2, location, chessColor, clickController2, size,isReversal);
        if (this.getChessColor() == ChessColor.RED) {
            name = "兵";
        } else {
            name = "卒";
        }
    }
    private Level level = Level.Bing;

    @Override
    public String toString() {
        if (getChessColor()==ChessColor.RED){
            return "Bing__R"+reversalStr();
        }else return "Bing__B"+reversalStr();
    }
    public Level getLevel() {
        return level;
    }
}
