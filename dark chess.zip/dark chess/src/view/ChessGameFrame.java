package view;

import chessComponent.*;
import controller.ClickController;
import controller.GameController;
import model.ChessColor;
import model.ChessboardPoint;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.Arrays;
import java.util.Objects;



/**
 * 这个类表示游戏窗体，窗体上包含：
 * 1 Chessboard: 棋盘
 * 2 JLabel:  标签
 * 3 JButton： 按钮
 */
public class ChessGameFrame extends JFrame {
    public static Clip clip = null;
    private final int WIDTH;
    private final int HEIGHT;
    public final int CHESSBOARD_SIZE;
    private GameController gameController;
    private static JLabel statusLabel;

    private static JLabel pointsLabel;
    public static JLabel redScoreLabel = new JLabel();
    public static JLabel blackScoreLabel = new JLabel();

    public static JLabel errormove = new JLabel("不可以这样移动哦~");
    public static ChessGameFrame CGFFF;
    //public static ChessGameFrame CGFFFF;
    public Chessboard chessboard;
    //很恶心的办法，但是我没办法；
    public static Chessboard CB;
    //public static JLabel labelll;
    public final Icon defaultIcon = new ImageIcon("resource/image/鼠标指向前.jpg");
    public final Icon enterIcon = new ImageIcon("resource/image/指向后.jpg");
    private final Icon pressedIcon = new ImageIcon("resource/image/点击后.jpg");
    private final Icon defaultSoundIcon = new ImageIcon("resource/image/开声音.jpg");
    private final Icon closeSoundIcon = new ImageIcon("resource/image/关声音.jpg");
    public static ImageIcon img = new ImageIcon();//这是背景图片
    public static JLabel imgLabel = new JLabel();//将背景图放在标签里。
    public static JButton musicbutton = new JButton();

    enum Name {
        Che___,Shi___,Bing__,Ma____,Jiang_,Xiang_,Pao___,______
    }

    public void background(String str){
        //加入背景图片
        img = null;
        imgLabel.setVisible(false);
        img = new ImageIcon("resource/image/"+ str +".png");//这是背景图片
        img.setImage(img.getImage().getScaledInstance(this.WIDTH, this.HEIGHT, Image.SCALE_DEFAULT));
//        JLabel imgLabel = new JLabel(img);//将背景图放在标签里。
        imgLabel = new JLabel(img);
        getLayeredPane().add(imgLabel, Integer.valueOf(Integer.MIN_VALUE));//注意这里是关键，将背景标签添加到jfram的LayeredPane面板里。
        imgLabel.setBounds(0, 0, WIDTH, HEIGHT);//设置背景标签的位置
        imgLabel.repaint();
        imgLabel.setVisible(true);
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        ((JPanel) cp).setOpaque(false);

    }

    public ChessGameFrame(int width, int height) {
        setTitle("一个好玩的 Dark ♂ chess"); //设置标题
        this.WIDTH = width;
        this.HEIGHT = height;
        this.CHESSBOARD_SIZE = HEIGHT * 4 / 5;


//        //加入背景图片
////        ImageIcon img = new ImageIcon("resource/image/背景1(1).png");//这是背景图片
//        img.setImage(img.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT));
//        JLabel imgLabel = new JLabel(img);//将背景图放在标签里。
//        getLayeredPane().add(imgLabel, Integer.valueOf(Integer.MIN_VALUE));//注意这里是关键，将背景标签添加到jfram的LayeredPane面板里。
//        imgLabel.setBounds(0, 0, WIDTH, HEIGHT);//设置背景标签的位置
//        Container cp = getContentPane();
//        cp.setLayout(new BorderLayout());
//        ((JPanel) cp).setOpaque(false);
        background("背景1(1)");


        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null); // Center the window.
        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置程序关闭按键，如果点击右上方的叉就游戏全部关闭了
        //setDefaultCloseOperation(ClickController.n);
        setLayout(null);



        CB = addChessboard();
        addLabel();
        addHelloButton();
        addLoadButton();
        addSaveButton();
        addRestartButton();
        addExitButton();
        addSoundControlButton();
        add666Button();
        addRedScoreLabel();
        addBlackScoreLabel();
        addJMenubar();


//        //进入游戏时播放BGM
//        try {
//            Clip clip = AudioSystem.getClip();
//            clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/20221126_022814转换格式.wav")));
//            clip.loop(Clip.LOOP_CONTINUOUSLY);
//        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
//            e.printStackTrace();
//        }
    }


    public JMenuBar addJMenubar (){
        //set music menu
        JMenuBar jmenubar = new JMenuBar();
        JMenu changemusic = new JMenu("背景音乐");
        JMenu changebackgroundpaint = new JMenu("背景图片");
        JMenu guanyuwomen = new JMenu("关于我们");

        JMenuItem zuiweidadezuopin = new JMenuItem("最伟大的作品-周杰伦");
        JMenuItem keainvren = new JMenuItem("可爱女人-周杰伦");
        JMenuItem huahai = new JMenuItem("花海-周杰伦");
        JMenuItem minemine = new JMenuItem("Mine Mine-周杰伦");
        JMenuItem qianlizhiwai = new JMenuItem("千里之外-周杰伦");

        JMenuItem tupian1 = new JMenuItem("背景1");
        JMenuItem tupian2 = new JMenuItem("背景2");
        JMenuItem tupian3 = new JMenuItem("背景3");

        JMenuItem womendeqq1 = new JMenuItem("QQ:2068438826");
        JMenuItem womendeqq2 = new JMenuItem("QQ:505314385");

        guanyuwomen.add(womendeqq1);
        guanyuwomen.add(womendeqq2);

        changemusic.add(zuiweidadezuopin);
        changemusic.add(keainvren);
        changemusic.add(huahai);
        changemusic.add(minemine);
        changemusic.add(qianlizhiwai);

        changebackgroundpaint.add(tupian1);
        changebackgroundpaint.add(tupian2);
        changebackgroundpaint.add(tupian3);

        jmenubar.add(changemusic);
        jmenubar.add(changebackgroundpaint);
        jmenubar.add(guanyuwomen);

        this.setJMenuBar(jmenubar);

        this.setVisible(true);

        zuiweidadezuopin.addActionListener(e ->{
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("最伟大的作品");
        });
        keainvren.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("可爱女人");
        });
        huahai.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("花海");
        });
        minemine.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("Mine Mine");
        });
        qianlizhiwai.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("千里之外");
        });

        tupian1.addActionListener(e -> {
            background("背景1(1)");
        });
        tupian2.addActionListener(e -> {
            System.out.println("wevgbksj");
            background("背景222(1)");
        });
        tupian3.addActionListener(e -> {
            background("背景333(1)");
        });

        return jmenubar;
    }


    /**
     * 在游戏窗体中添加棋盘
     */
    private Chessboard addChessboard() {
        Chessboard chessboard = new Chessboard(CHESSBOARD_SIZE / 2, CHESSBOARD_SIZE);
        gameController = new GameController(chessboard);
        //************************!!!!!!!!!!!!!!!!!!!!!!!!!
        chessboard.setLocation(HEIGHT / 6, HEIGHT / 10);
        add(chessboard);
        this.chessboard = chessboard;
        return chessboard;
    }

    /**
     * 在游戏窗体中添加标签
     */
    private void addLabel() {
        statusLabel = new JLabel("Click to decide whose turn");
        statusLabel.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 35);
        statusLabel.setSize(250, 60);
        statusLabel.setFont(new Font("Rock", Font.BOLD, 15));
        add(statusLabel);
        //return statusLabel;
    }

    //  protected void addRedScore(Graphics redScore) {
//        redScore.setColor(Color.RED);
//        redScore.setFont(new Font());
//       // redScore.setFont(Rock);
//    }
    public void addRedScoreLabel() {
//        String str1 = "红方：" + 0 + "分";
//        redScoreLabel.setText(str1);
        //       redScoreLabel = new JLabel("红方：" + 0 + "分");
        redScoreLabel.setText("红方：" + 0 + "分");
        redScoreLabel.setLocation(WIDTH * 42 / 50 - 20, HEIGHT * 13 / 200 - 16);
        redScoreLabel.setSize(250, 70);
        redScoreLabel.setFont(new Font("Rock", Font.BOLD, 25));
        add(redScoreLabel);
    }

    public void addBlackScoreLabel() {
        //BlackScoreLabel = new JLabel("黑方：" + 0 + "分");
        // redScoreLabel.setText("shabi");
        blackScoreLabel.setText("黑方：" + 0 + "分");
        blackScoreLabel.setLocation(WIDTH * 42 / 50 - 20, HEIGHT * 2 / 200 - 16);
        blackScoreLabel.setSize(250, 70);
        blackScoreLabel.setFont(new Font("Rock", Font.BOLD, 25));
        add(blackScoreLabel);
    }


    public static JLabel getStatusLabel() {
        return statusLabel;
    }

    /**
     * 在游戏窗体中增加一个按钮，如果按下的话就会显示Hello, world!
     */

    private void add666Button() {
        JButton button = new JButton("666");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setLocation(WIDTH * 4 / 5 + 80, HEIGHT * 4 / 5);
        button.setSize(70, 50);
        button.setFont(new Font("Rock", Font.BOLD, 18));
        add(button);
        int arri[][] = new int[8][4];
        //int arr2[] = new int[4];
//        for (int i = 0; i < arri.length; i++) {
//            for (int i1 = 0; i1 < arri[i].length; i1++) {
//                arri[i][i1] = -999;
//            }
//        }
        //加入鼠标监听
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                for (int i = 0; i < arri.length; i++) {
                    for (int i1 = 0; i1 < arri[i].length; i1++) {
                        arri[i][i1] = -999;
                    }
                }
                button.setIcon(pressedIcon);
                for (int i = 0; i < chessboard.squareComponents.length; i++) {
                    for (int i1 = 0; i1 < chessboard.squareComponents[i].length; i1++) {
                        if (!chessboard.squareComponents[i][i1].isReversal) {
                            chessboard.squareComponents[i][i1].setReversal(true);
                            //          chessboard.squareComponents[i][i1].draw;
                            chessboard.squareComponents[i][i1].repaint();
                            arri[i][i1] = 9;
                        }
                    }
                }

            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
                for (int i = 0; i < arri.length; i++) {
                    for (int i1 = 0; i1 < arri[i].length; i1++) {
                        if (arri[i][i1] != -999) {
                            chessboard.squareComponents[i][i1].setReversal(false);
                            chessboard.squareComponents[i][i1].repaint();
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

    private void addHelloButton() {
        JButton button = new JButton("Hello");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);


        button.addActionListener(e -> JOptionPane.showMessageDialog(this, "达咩~不要点我哟~"));
        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 120 - 25);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        add(button);

        //加入鼠标监听
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //有时间了可以做得更好
                //JOptionPane.showMessageDialog(null, "达咩~不要点我哟~");
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
                try {
                    wait(100);
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }


    //
    //
//    private final Icon defaultIcon = new ImageIcon("resource/image/BA{EPQQ33]JD@M(1NVM[VAT.png");
//    private final Icon enterIcon = new ImageIcon("C:\\Users\\许国祥\\Desktop\\123456\\resource\\image\\b5c6b66b652dfd4646e70630aba9ec5a.jpeg");
//    private final Icon pressedIcon = new ImageIcon("C:\\Users\\许国祥\\Desktop\\123456\\resource\\image\\9893542a158de888a252c246aa76add9.jpeg");
    private void addLoadButton() {
        JButton button = new JButton("Load");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);


        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 240 - 25 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rockwell", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);

        button.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser("./resource") {{//设置默认路径
                setSelectedFile(new File("save.txt"));//设置默认文件名
                setFileFilter(new FileNameExtensionFilter("*.txt", "txt"));//设置文件过滤器
            }};
            int res = fileChooser.showOpenDialog(this);
            if (res == JFileChooser.APPROVE_OPTION) {//如果点击了“确认”
                if (1 == 1
                        //Objects.equals(fileChooser.getTypeDescription(fileChooser.getSelectedFile()), "txt")
                ){//判断文件类型是否为“文本文档”
                    label:
                    try {
                        FileReader fileReader = new FileReader(fileChooser.getSelectedFile());
                        BufferedReader reader = new BufferedReader(fileReader);
                        String line = reader.readLine();
                        String[] getSaveStr = line.replace("[", "").replace("]", "").split(", ");
                        //在这里写方法遍历s中的每一项
                        if (getSaveStr.length >= 32) {
                            for (int i = 0; i < 32; i++) {
                                if (getSaveStr[i].equals("RED_____") || getSaveStr[i].equals("BLACK___")) {
                                    JOptionPane.showMessageDialog(null, "The wrong size of chessboard.","Errol Type : 102", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                } else if (!(getSaveStr[i].charAt(6) == 'R' || getSaveStr[i].charAt(6) == 'B' || getSaveStr[i].substring(6, 8).equals("__"))){
                                    JOptionPane.showMessageDialog(null, "The wrong type of chess.","Errol Type : 103", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                } else if (getSaveStr[i].charAt(7) != '+' && getSaveStr[i].charAt(7) != '-' && !getSaveStr[i].substring(6, 8).equals("__")) {
                                    JOptionPane.showMessageDialog(null, "The wrong type of chess.","Errol Type : 103", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                } else if (!Arrays.toString(Name.values()).contains(getSaveStr[i].substring(0, 6))) {
                                    JOptionPane.showMessageDialog(null, "The wrong type of chess.","Errol Type : 103", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                }
                            }
                            if (!getSaveStr[32].equals("RED_____") && !getSaveStr[32].equals("BLACK___")){
                                JOptionPane.showMessageDialog(null, "Lack of current color.","Errol Type : 104", JOptionPane.PLAIN_MESSAGE);
                                break label;
                            }
                            SquareComponent[][] sc = chessboard.squareComponents;
                            //chessboard.setVisible(false);
                            //chessboard = new Chessboard(CHESSBOARD_SIZE / 2, CHESSBOARD_SIZE, chessboard.squareComponents);
                            chessboard = CB;
                            gameController = new GameController(chessboard);
                            chessboard.setLocation(HEIGHT / 6, HEIGHT / 10);
                            add(chessboard);
                            //this.chessboard = chessboard;

                            //***********************************
                            ClickController.setEatenIndex();
                            ClickController.BlackPoint = 0;
                            ClickController.RedPoint = 0;

                            ClickController ccc = chessboard.clickController;
                            for (int i = 0; i < 32; i++) {
                                sc[i / 4][i % 4].setVisible(false);
                                //当前棋子的红黑方：
                                ChessColor dangqianqizidehongheifang = ChessColor.BLACK;
                                //当前棋子的坐标：
                                ChessboardPoint qizidezuobiao = new ChessboardPoint(i / 4, i % 4);
                                //当前棋子是否翻转
                                Boolean reversalllll = false;
                                switch (getSaveStr[i].charAt(6)) {
                                    case 'R':
                                        dangqianqizidehongheifang = ChessColor.RED;
                                        break;
                                    case 'B':
                                        dangqianqizidehongheifang = ChessColor.BLACK;
                                        break;
                                }
                                switch (getSaveStr[i].charAt(7)) {
                                    case '+':
                                        reversalllll = true;
                                        break;
                                    case '-':
                                        reversalllll = false;
                                        break;
                                }
                                String getSubStr = getSaveStr[i].substring(0, 6);

                                //对于不同的substring，进行判断，之后new一个判断出来的对象（与 Load 一致）以覆盖现有对象；
                                switch (getSubStr) {
                                    case "Che___":
                                        ChariotChessComponent current = new ChariotChessComponent(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard.CHESS_SIZE, reversalllll);
                                        sc[i / 4][i % 4] = null;
                                        sc[i / 4][i % 4] = current;
                                        break;
                                    case "Jiang_":
                                        sc[i / 4][i % 4] = new JiangCC(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Ma____":
                                        sc[i / 4][i % 4] = new MaCC(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Pao___":
                                        sc[i / 4][i % 4] = new PaoCC(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Shi___":
                                        sc[i / 4][i % 4] = new ShiChessComponent(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Bing__":
                                        sc[i / 4][i % 4] = new SoldierChessComponent(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Xiang_":
                                        sc[i / 4][i % 4] = new XiangCC(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard.CHESS_SIZE, reversalllll);
                                        break;
                                    case "______":
                                        sc[i / 4][i % 4] = new EmptySlotComponent(qizidezuobiao, sc[i / 4][i % 4].getLocation(), ccc, chessboard.CHESS_SIZE, true);
                                        System.out.println("111");
                                        break;
                                }
                                sc[i / 4][i % 4].repaint();
                                sc[i / 4][i % 4].setVisible(true);

                            }
                            //sc[0][0]=new ChariotChessComponent();
                            System.out.println(Arrays.toString(getSaveStr));
                            chessboard.putOnBoard();
                            if (Objects.equals(getSaveStr[32], "RED_____")) {
                                chessboard.setCurrentColor(ChessColor.RED);
                                ChessGameFrame.getStatusLabel().setText(String.format("%s's TURN", chessboard.currentColor));
                            } else if (Objects.equals(getSaveStr[32], "BLACK___")) {
                                chessboard.setCurrentColor(ChessColor.BLACK);
                                ChessGameFrame.getStatusLabel().setText(String.format("%s's TURN", chessboard.currentColor));
                            } else {
                                ClickController.rev = 0;
                                ChessGameFrame.getStatusLabel().setText("Click to decide whose turn");
                            }
                            if (getSaveStr[33].charAt(1) == '_') {
                                ClickController.BlackPoint = getSaveStr[33].charAt(0) - 48;
                                ChessGameFrame.blackScoreLabel.setText("黑方：" + ClickController.BlackPoint + "分");
                            } else {
                                ClickController.BlackPoint = (getSaveStr[33].charAt(0) - 48) * 10 + getSaveStr[33].charAt(1) - 48;
                                ChessGameFrame.blackScoreLabel.setText("黑方：" + ClickController.BlackPoint + "分");
                            }
                            if (getSaveStr[34].charAt(1) == '_') {
                                ClickController.RedPoint = getSaveStr[34].charAt(0) - 48;
                                ChessGameFrame.redScoreLabel.setText("红方：" + ClickController.RedPoint + "分");
                            } else {
                                ClickController.RedPoint = (getSaveStr[34].charAt(0) - 48) * 10 + getSaveStr[34].charAt(1) - 48;
                                ChessGameFrame.redScoreLabel.setText("红方：" + ClickController.RedPoint + "分");
                            }
                            ClickController.bbche = getSaveStr[35].charAt(0) - 48 - 1;
                            ClickController.rrche = getSaveStr[36].charAt(0) - 48 - 1;
                            ClickController.bbjiang = getSaveStr[37].charAt(0) - 48 - 1;
                            ClickController.rrjiang = getSaveStr[38].charAt(0) - 48 - 1;
                            ClickController.bbma = getSaveStr[39].charAt(0) - 48 - 1;
                            ClickController.rrma = getSaveStr[40].charAt(0) - 48 - 1;
                            ClickController.bbpao = getSaveStr[41].charAt(0) - 48 - 1;
                            ClickController.rrpao = getSaveStr[42].charAt(0) - 48 - 1;
                            ClickController.bbshi = getSaveStr[43].charAt(0) - 48 - 1;
                            ClickController.rrshi = getSaveStr[44].charAt(0) - 48 - 1;
                            ClickController.bbbing = getSaveStr[45].charAt(0) - 48 - 1;
                            ClickController.rrbing = getSaveStr[46].charAt(0) - 48 - 1;
                            ClickController.bbxiang = getSaveStr[47].charAt(0) - 48 - 1;
                            ClickController.rrxiang = getSaveStr[48].charAt(0) - 48 - 1;
                            if (ClickController.bbche == 0) {
                                ClickController.jLabel1.setIcon(ClickController.bche1);
                                ClickController.jLabel1.setLocation(57 - 10 * ClickController.bbche, 85);
                                ClickController.jLabel1.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel1);
                                ClickController.jLabel1.repaint();
                                ClickController.bbche = ClickController.bbche + 1;
                            } else if (ClickController.bbche == 1) {
                                ClickController.jLabel1.setIcon(ClickController.bche2);
                                ClickController.jLabel1.setLocation(57 - 10 * ClickController.bbche, 85);
                                ClickController.jLabel1.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel1);
                                ClickController.jLabel1.repaint();
                                ClickController.bbche = ClickController.bbche + 1;
                            }

                            if (ClickController.rrche == 0) {
                                ClickController.jLabel2.setIcon(ClickController.rche1);
                                ClickController.jLabel2.setLocation(435 + 10 * ClickController.rrche, 85);
                                ClickController.jLabel2.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel2);
                                ClickController.jLabel2.repaint();
                                ClickController.rrche = ClickController.rrche + 1;
                            } else if (ClickController.rrche == 1) {
                                ClickController.jLabel2.setIcon(ClickController.rche2);
                                ClickController.jLabel2.setLocation(435 + 10 * ClickController.rrche, 85);
                                ClickController.jLabel2.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel2);
                                ClickController.jLabel2.repaint();
                                ClickController.rrche = ClickController.rrche + 1;
                            }
                            if (ClickController.bbma == 0) {
                                ClickController.jLabel4.setIcon(ClickController.bma1);
                                ClickController.jLabel4.setLocation(57 - 10 * ClickController.bbma, 85 + 68 * 1);
                                ClickController.jLabel4.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel4);
                                ClickController.jLabel4.repaint();
                                ClickController.bbma = ClickController.bbma + 1;
                            } else if (ClickController.bbma == 1) {
                                ClickController.jLabel4.setIcon(ClickController.bma2);
                                ClickController.jLabel4.setLocation(57 - 10 * ClickController.bbma, 85 + 68 * 1);
                                ClickController.jLabel4.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel4);
                                ClickController.jLabel4.repaint();
                                ClickController.bbma = ClickController.bbma + 1;
                            }

                            if (ClickController.rrma == 0) {
                                ClickController.jLabel3.setIcon(ClickController.rma1);
                                ClickController.jLabel3.setLocation(435 + 10 * ClickController.rrma, 85 + 68 * 1);
                                ClickController.jLabel3.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel3);
                                ClickController.jLabel3.repaint();
                                ClickController.rrma = ClickController.rrma + 1;
                            } else if (ClickController.rrma == 1) {
                                ClickController.jLabel3.setIcon(ClickController.rma2);
                                ClickController.jLabel3.setLocation(435 + 10 * ClickController.rrma, 85 + 68 * 1);
                                ClickController.jLabel3.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel3);
                                ClickController.jLabel3.repaint();
                                ClickController.rrma = ClickController.rrma + 1;

                            }

                            if (ClickController.bbpao == 0) {
                                ClickController.jLabel5.setIcon(ClickController.bpao1);
                                ClickController.jLabel5.setLocation(57 - 10 * ClickController.bbpao, 85 + 68 * 2);
                                ClickController.jLabel5.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel5);
                                ClickController.jLabel5.repaint();
                                ClickController.bbpao = ClickController.bbpao + 1;
                            } else if (ClickController.bbpao == 1) {
                                ClickController.jLabel5.setIcon(ClickController.bpao2);
                                ClickController.jLabel5.setLocation(57 - 10 * ClickController.bbpao, 85 + 68 * 2);
                                ClickController.jLabel5.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel5);
                                ClickController.jLabel5.repaint();
                                ClickController.bbpao = ClickController.bbpao + 1;
                            }

                            if (ClickController.rrpao == 0) {
                                ClickController.jLabel6.setIcon(ClickController.rpao1);
                                ClickController.jLabel6.setLocation(435 + 10 * ClickController.rrpao, 85 + 68 * 2);
                                ClickController.jLabel6.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel6);
                                ClickController.jLabel6.repaint();
                                ClickController.rrpao = ClickController.rrpao + 1;
                            } else if (ClickController.rrpao == 1) {
                                ClickController.jLabel6.setIcon(ClickController.rpao2);
                                ClickController.jLabel6.setLocation(435 + 10 * ClickController.rrpao, 85 + 68 * 2);
                                ClickController.jLabel6.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel6);
                                ClickController.jLabel6.repaint();
                                ClickController.rrpao = ClickController.rrpao + 1;
                            }


                            if (ClickController.bbshi == 0) {
                                ClickController.jLabel7.setIcon(ClickController.bshi1);
                                ClickController.jLabel7.setLocation(57 - 10 * ClickController.bbshi, 85 + 68 * 3);
                                ClickController.jLabel7.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel7);
                                ClickController.jLabel7.repaint();
                                ClickController.bbshi = ClickController.bbshi + 1;
                            } else if (ClickController.bbshi == 1) {
                                ClickController.jLabel7.setIcon(ClickController.bshi2);
                                ClickController.jLabel7.setLocation(57 - 10 * ClickController.bbshi, 85 + 68 * 3);
                                ClickController.jLabel7.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel7);
                                ClickController.jLabel7.repaint();
                                ClickController.bbshi = ClickController.bbshi + 1;
                            }

                            if (ClickController.rrshi == 0) {
                                ClickController.jLabel8.setIcon(ClickController.rshi1);
                                ClickController.jLabel8.setLocation(435 + 10 * ClickController.rrshi, 85 + 68 * 3);
                                ClickController.jLabel8.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel8);
                                ClickController.jLabel8.repaint();
                                ClickController.rrshi = ClickController.rrshi + 1;
                            } else if (ClickController.rrshi == 1) {
                                ClickController.jLabel8.setIcon(ClickController.rshi2);
                                ClickController.jLabel8.setLocation(435 + 10 * ClickController.rrshi, 85 + 68 * 3);
                                ClickController.jLabel8.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel8);
                                ClickController.jLabel8.repaint();
                                ClickController.rrshi = ClickController.rrshi + 1;
                            }

                            if (ClickController.bbbing == 0) {
                                ClickController.jLabel9.setIcon(ClickController.bbing1);
                                ClickController.jLabel9.setLocation(57 - 10 * ClickController.bbbing, 85 + 68 * 4);
                                ClickController.jLabel9.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel9);
                                ClickController.jLabel9.repaint();
                                ClickController.bbbing = ClickController.bbbing + 1;
                            } else if (ClickController.bbbing == 1) {
                                ClickController.jLabel9.setIcon(ClickController.bbing2);
                                ClickController.jLabel9.setLocation(57 - 10 * ClickController.bbbing, 85 + 68 * 4);
                                ClickController.jLabel9.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel9);
                                ClickController.jLabel9.repaint();
                                ClickController.bbbing = ClickController.bbbing + 1;
                            } else if (ClickController.bbbing == 2) {
                                ClickController.jLabel9.setIcon(ClickController.bbing3);
                                ClickController.jLabel9.setLocation(57 - 10 * ClickController.bbbing, 85 + 68 * 4);
                                ClickController.jLabel9.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel9);
                                ClickController.jLabel9.repaint();
                                ClickController.bbbing = ClickController.bbbing + 1;
                            } else if (ClickController.bbbing == 3) {
                                ClickController.jLabel9.setIcon(ClickController.bbing4);
                                ClickController.jLabel9.setLocation(57 - 10 * ClickController.bbbing, 85 + 68 * 4);
                                ClickController.jLabel9.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel9);
                                ClickController.jLabel9.repaint();
                                ClickController.bbbing = ClickController.bbbing + 1;
                            } else if (ClickController.bbbing == 4) {
                                ClickController.jLabel9.setIcon(ClickController.bbing5);
                                ClickController.jLabel9.setLocation(57 - 10 * ClickController.bbbing, 85 + 68 * 4);
                                ClickController.jLabel9.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel9);
                                ClickController.jLabel9.repaint();
                                ClickController.bbbing = ClickController.bbbing + 1;
                            }

                            if (ClickController.rrbing == 0) {
                                ClickController.jLabel10.setIcon(ClickController.rbing1);
                                ClickController.jLabel10.setLocation(435 + 10 * ClickController.rrbing, 85 + 68 * 4);
                                ClickController.jLabel10.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel10);
                                ClickController.jLabel10.repaint();
                                ClickController.rrbing = ClickController.rrbing + 1;
                            } else if (ClickController.rrbing == 1) {
                                ClickController.jLabel10.setIcon(ClickController.rbing2);
                                ClickController.jLabel10.setLocation(435 + 10 * ClickController.rrbing, 85 + 68 * 4);
                                ClickController.jLabel10.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel10);
                                ClickController.jLabel10.repaint();
                                ClickController.rrbing = ClickController.rrbing + 1;
                            } else if (ClickController.rrbing == 2) {
                                ClickController.jLabel10.setIcon(ClickController.rbing3);
                                ClickController.jLabel10.setLocation(435 + 10 * ClickController.rrbing, 85 + 68 * 4);
                                ClickController.jLabel10.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel10);
                                ClickController.jLabel10.repaint();
                                ClickController.rrbing = ClickController.rrbing + 1;
                            } else if (ClickController.rrbing == 3) {
                                ClickController.jLabel10.setIcon(ClickController.rbing4);
                                ClickController.jLabel10.setLocation(435 + 10 * ClickController.rrbing, 85 + 68 * 4);
                                ClickController.jLabel10.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel10);
                                ClickController.jLabel10.repaint();
                                ClickController.rrbing = ClickController.rrbing + 1;

                            } else if (ClickController.rrbing == 4) {
                                ClickController.jLabel10.setIcon(ClickController.rbing5);
                                ClickController.jLabel10.setLocation(435 + 10 * ClickController.rrbing, 85 + 68 * 4);
                                ClickController.jLabel10.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel10);
                                ClickController.jLabel10.repaint();
                                ClickController.rrbing = ClickController.rrbing + 1;
                            }

                            if (ClickController.bbxiang == 0) {
                                ClickController.jLabel11.setIcon(ClickController.bxiang1);
                                ClickController.jLabel11.setLocation(57 - 10 * ClickController.bbxiang, 85 + 68 * 5);
                                ClickController.jLabel11.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel11);
                                ClickController.jLabel11.repaint();
                                ClickController.bbxiang = ClickController.bbxiang + 1;
                            } else if (ClickController.bbxiang == 1) {
                                ClickController.jLabel11.setIcon(ClickController.bxiang2);
                                ClickController.jLabel11.setLocation(57 - 10 * ClickController.bbxiang, 85 + 68 * 5);
                                ClickController.jLabel11.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel11);
                                ClickController.jLabel11.repaint();
                                ClickController.bbxiang = ClickController.bbxiang + 1;
                            }

                            if (ClickController.rrxiang == 0) {
                                ClickController.jLabel12.setIcon(ClickController.rxiang1);
                                ClickController.jLabel12.setLocation(435 + 10 * ClickController.rrxiang, 85 + 68 * 5);
                                ClickController.jLabel12.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel12);
                                ClickController.jLabel12.repaint();
                                ClickController.rrxiang = ClickController.rrxiang + 1;
                            } else if (ClickController.rrxiang == 1) {
                                ClickController.jLabel12.setIcon(ClickController.rxiang2);
                                ClickController.jLabel12.setLocation(435 + 10 * ClickController.rrxiang, 85 + 68 * 5);
                                ClickController.jLabel12.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel12);
                                ClickController.jLabel12.repaint();
                                ClickController.rrxiang = ClickController.rrxiang + 1;
                            }

                            if (ClickController.bbjiang == 0) {
                                ClickController.jLabel13.setIcon(ClickController.bjiang1);
                                ClickController.jLabel13.setLocation(57 - 10 * ClickController.bbjiang, 85 + 68 * 6);
                                ClickController.jLabel13.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel13);
                                ClickController.jLabel13.repaint();
                                ClickController.bbjiang = ClickController.bbjiang + 1;
                            }

                            if (ClickController.rrxiang == 0) {
                                ClickController.jLabel14.setIcon(ClickController.rjiang1);
                                ClickController.jLabel14.setLocation(435 + 10 * ClickController.rrxiang, 85 + 68 * 6);
                                ClickController.jLabel14.setSize(60, 60);
                                ChessGameFrame.CGFFF.getContentPane().add(ClickController.jLabel14);
                                ClickController.jLabel14.repaint();
                                ClickController.rrjiang = ClickController.rrjiang + 1;
                            }

                            ClickController.bbche ++;
                            ClickController.rrche ++;
                            ClickController.bbjiang ++;
                            ClickController.rrjiang ++;
                            ClickController.bbma ++;
                            ClickController.rrma ++;
                            ClickController.bbpao ++;
                            ClickController.rrpao ++;
                            ClickController.bbshi ++;
                            ClickController.rrshi ++;
                            ClickController.bbbing ++;
                            ClickController.rrbing ++;
                            ClickController.bbxiang ++;
                            ClickController.rrxiang ++;

                            reader.close();
                            fileReader.close();
                        } else {
                            JOptionPane.showMessageDialog(null, "The wrong size of chessboard.","Errol Type : 102", JOptionPane.PLAIN_MESSAGE);
                        }
                    }catch (Exception ee) {
                        ee.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "The wrong type of file.","Errol Type : 101", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });


//        //加入鼠标监听
//        MouseListener loadBottonMouseListener = new MouseListener() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//                button.setIcon(pressedIcon);
//            }
//
//            @Override
//            public void mousePressed(MouseEvent e) {
//                button.setIcon(pressedIcon);
//            }
//
//            @Override
//            public void mouseReleased(MouseEvent e) {
//                button.setIcon(enterIcon);
//            }
//
//            @Override
//            public void mouseEntered(MouseEvent e) {
//                button.setIcon(enterIcon);
//            }
//
//            @Override
//            public void mouseExited(MouseEvent e) {
//                button.setIcon(defaultIcon);
//            }
//        };

        //加入鼠标监听
        button.addMouseListener(new

                                        MouseListener() {
                                            @Override
                                            public void mouseClicked(MouseEvent e) {
                                                button.setIcon(pressedIcon);
                                            }

                                            @Override
                                            public void mousePressed(MouseEvent e) {
                                                button.setIcon(pressedIcon);
                                            }

                                            @Override
                                            public void mouseReleased(MouseEvent e) {
                                                button.setIcon(enterIcon);
                                            }

                                            @Override
                                            public void mouseEntered(MouseEvent e) {
                                                button.setIcon(enterIcon);
                                            }

                                            @Override
                                            public void mouseExited(MouseEvent e) {
                                                button.setIcon(defaultIcon);
                                            }
                                        });

    }


    private void addSaveButton() {
        JButton button = new JButton("Save");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);


        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 360 - 25 - 15 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);

        button.addActionListener(action -> {
            JFileChooser fileChooser = new JFileChooser("./resource") {{//设置默认路径
                setSelectedFile(new File("save.txt"));//设置默认文件名
                setFileFilter(new FileNameExtensionFilter("*.txt", "txt"));//设置文件过滤器
            }};
            String[] s = new String[49];
            int res = fileChooser.showSaveDialog(this);
            if (res == JFileChooser.APPROVE_OPTION) {//如果点击了“保存”
                try (FileWriter writer = new FileWriter(fileChooser.getSelectedFile())) {
                    int i = 0;
                    for (SquareComponent[] a : chessboard.squareComponents) {
                        for (SquareComponent b : a) {
                            s[i] = b.toString();
                            i++;
                        }
                    }
                    s[32] = chessboard.currentcolorToString();
                    if (ClickController.BlackPoint < 10) {
                        s[33] = ClickController.BlackPoint + "______B";
                    } else {
                        s[33] = ClickController.BlackPoint + "_____B";
                    }
                    if (ClickController.RedPoint < 10) {
                        s[34] = ClickController.RedPoint + "______R";
                    } else {
                        s[34] = ClickController.RedPoint + "_____R";
                    }
                    int eatenarr[] = new int[14];
                    eatenarr[0] = ClickController.bbche;
                    eatenarr[1] = ClickController.rrche;
                    eatenarr[2] = ClickController.bbjiang;
                    eatenarr[3] = ClickController.rrjiang;
                    eatenarr[4] = ClickController.bbma;
                    eatenarr[5] = ClickController.rrma;
                    eatenarr[6] = ClickController.bbpao;
                    eatenarr[7] = ClickController.rrpao;
                    eatenarr[8] = ClickController.bbshi;
                    eatenarr[9] = ClickController.rrshi;
                    eatenarr[10] = ClickController.bbbing;
                    eatenarr[11] = ClickController.rrbing;
                    eatenarr[12] = ClickController.bbxiang;
                    eatenarr[13] = ClickController.rrxiang;
                    for (int i1 = 0; i1 < eatenarr.length; i1++) {
                        s[i1 + 35] = eatenarr[i1] + "____EEE";
                    }
                    writer.write(Arrays.toString(s));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //加入鼠标监听；
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });

    }

    public void addRestartButton() {
        JButton button = new JButton("Restart");
        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 480 - 25 - 15 - 15 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);
        button.addActionListener(action -> {
            int n2 = JOptionPane.showConfirmDialog(null, "是否重新开始？", "", JOptionPane.YES_NO_OPTION);
            if (n2 == 0) {
                ClickController.setEatenIndex();
                ClickController.BlackPoint = 0;
                ClickController.RedPoint = 0;
                ClickController.rev = 0;
                ChessGameFrame.blackScoreLabel.setText("黑方：" + ClickController.BlackPoint + "分");
                ChessGameFrame.redScoreLabel.setText("红方：" + ClickController.RedPoint + "分");
                ChessGameFrame.CB.cleanChessOfBord();
                ChessGameFrame.CB.initAllChessOnBoard();
                ChessGameFrame.getStatusLabel().setText("Click to decide whose turn");
            }
        });
        //加入鼠标监听；
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

    public void addExitButton() {
        JButton button = new JButton("Exit");
        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 600 - 25 - 15 - 15 - 15 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);
        button.addActionListener(action -> {
            int n3 = JOptionPane.showConfirmDialog(null, "是否退出？", "", JOptionPane.YES_NO_OPTION);
            if (n3 == 0) {
                CGFFF.dispatchEvent(new WindowEvent(CGFFF, WindowEvent.WINDOW_CLOSING));
            }
        });
        //加入鼠标监听；
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

    public static Clip sounddddd(String str) {
        //进入游戏时播放BGM
 //       Clip clip = null;
        try {
            clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/" + str + "-周杰伦.wav")));
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
            e.printStackTrace();
        }
        return clip;
    }

    private void addSoundControlButton() {
        musicbutton = new JButton();

        //给按钮设置默认背景颜色
        musicbutton.setIcon(defaultSoundIcon);
        //使按钮的字一直位于上方和中央
//        button.setVerticalTextPosition(SwingConstants.CENTER);
//        button.setHorizontalTextPosition(SwingConstants.CENTER);
        musicbutton.setLocation(WIDTH * 4 / 5, HEIGHT * 4 / 5);
        musicbutton.setSize(50, 50);
        //  button.setFont(new Font("Rockwell", Font.BOLD, 20));
        //  button.setBackground(Color.LIGHT_GRAY);
        add(musicbutton);

        sounddddd("千里之外");

            //加入鼠标监听；
            musicbutton.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {

                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (musicbutton.getIcon().equals(defaultSoundIcon)) {
                        musicbutton.setIcon(closeSoundIcon);
//                    try {
//
//                    } catch (LineUnavailableException ex) {
//                        throw new RuntimeException(ex);
//                    }
                        //clip.close();
                        clip.stop();
                    } else {
//                    try {
//                        Clip clip = AudioSystem.getClip();
//                        clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/20221126_022814转换格式.wav")));
//                        clip.loop(0);
//
//
//                        button.setIcon(defaultSoundIcon);
//                    } catch (LineUnavailableException | UnsupportedAudioFileException | IOException f) {
//                        f.printStackTrace();
                        clip.start();
                        musicbutton.setIcon(defaultSoundIcon);
                    }

                }

                @Override
                public void mouseReleased(MouseEvent e) {

                }

                @Override
                public void mouseEntered(MouseEvent e) {

                }

                @Override
                public void mouseExited(MouseEvent e) {

                }
            });

//        }
//        catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
//            e.printStackTrace();
//        }

    }

    public static ChessGameFrame newgame() {
        ChessGameFrame mainFrame = new ChessGameFrame(1024, 750);
        SwingUtilities.invokeLater(() -> {
            mainFrame.setVisible(true);
        });
//        SwingUtilities.invokeLater(() -> {
//            ChessGameFrame mainFrame = new ChessGameFrame(1024, 750);
//            mainFrame.setVisible(true);
//        });
        return mainFrame;
    }

    public ChessGameFrame getGameFrame() {
        return this;
    }

}
