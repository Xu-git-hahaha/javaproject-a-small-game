package view;


import Level.Level;
import chessComponent.*;
import model.*;
import controller.ClickController;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Random;

/**
 * 这个类表示棋盘组建，其包含：
 * SquareComponent[][]: 4*8个方块格子组件
 */
public class Chessboard extends JComponent {


    private static final int ROW_SIZE = 8;
    private static final int COL_SIZE = 4;

    //public static SquareComponent[][] squareComponents = new SquareComponent[ROW_SIZE][COL_SIZE];
    public SquareComponent[][] squareComponents = new SquareComponent[ROW_SIZE][COL_SIZE];
    //public  final SquareComponent[][] squareComponents = new SquareComponent[ROW_SIZE][COL_SIZE];
    //todo: you can change the initial player
    public ChessColor currentColor = ChessColor.NONE;

    //all chessComponents in this chessboard are shared only one model controller
    public final ClickController clickController = new ClickController(this);
    public final int CHESS_SIZE;


    public String currentcolorToString(){
        if(currentColor == ChessColor.BLACK){
            return "BLACK___";
        }else if(currentColor == ChessColor.RED){
            return "RED_____";
        }
        return "NONE____";
    }


    public Chessboard(int width, int height,SquareComponent[][] squareComponents) {
        setLayout(null); // Use absolute layout.
        setSize(width + 2, height);
        CHESS_SIZE = (height - 6) / 8;
        SquareComponent.setSpacingLength(CHESS_SIZE / 12);
        System.out.printf("chessboard [%d * %d], chess size = %d\n", width, height, CHESS_SIZE);
        this.squareComponents=squareComponents;
    }

    public Chessboard(int width, int height) {
        setLayout(null); // Use absolute layout.
        setSize(width + 2, height);
        CHESS_SIZE = (height - 6) / 8;
        SquareComponent.setSpacingLength(CHESS_SIZE / 12);
        System.out.printf("chessboard [%d * %d], chess size = %d\n", width, height, CHESS_SIZE);
        initAllChessOnBoard();
    }
    public SquareComponent[][] getChessComponents() {
        return squareComponents;
    }

    public ChessColor getCurrentColor() {
        return currentColor;
    }

    public void setCurrentColor(ChessColor currentColor) {
        this.currentColor = currentColor;
    }

    /**
     * 将SquareComponent 放置在 ChessBoard上。里面包含移除原有的component及放置新的component
     */
    public void putChessOnBoard(SquareComponent squareComponent) {
        int row = squareComponent.getChessboardPoint().getX(), col = squareComponent.getChessboardPoint().getY();
        if (squareComponents[row][col] != null) {
            remove(squareComponents[row][col]);
        }
        add(squareComponents[row][col] = squareComponent);
    }

    /**
     * 交换chess1 chess2的位置
     */
    public boolean swapChessComponents(SquareComponent chess1, SquareComponent chess2) {
        if (canEat(chess1.getLevel(), chess2.getLevel()) && canMove(chess1,chess2)) {
            // Note that chess1 has higher priority, 'destroys' chess2 if exists.
            if (!(chess2 instanceof EmptySlotComponent)) {
                remove(chess2);
                add(chess2 = new EmptySlotComponent(chess2.getChessboardPoint(), chess2.getLocation(), clickController, CHESS_SIZE, false));
            }

//                remove(chess2);
//                add(chess2 = new EmptySlotComponent(chess2.getChessboardPoint(), chess2.getLocation(), clickController, CHESS_SIZE, false));

//            if(chess2 instanceof EmptySlotComponent){
//
//            }
            chess1.swapLocation(chess2);
            int row1 = chess1.getChessboardPoint().getX(), col1 = chess1.getChessboardPoint().getY();
            squareComponents[row1][col1] = chess1;
            int row2 = chess2.getChessboardPoint().getX(), col2 = chess2.getChessboardPoint().getY();
            squareComponents[row2][col2] = chess2;

            //只重新绘制chess1 chess2，其他不变
            chess1.repaint();
            chess2.repaint();
            return true;
        }
        return false;
    }

    /**
     * 用来表示炮的吃子行为
     * @param chess1 炮
     * @param chess2 被吃的子
     */
    public void Paoswap(SquareComponent chess1, SquareComponent chess2) {
        if (!(chess2 instanceof EmptySlotComponent)) {
            remove(chess2);
            add(chess2 = new EmptySlotComponent(chess2.getChessboardPoint(), chess2.getLocation(), clickController, CHESS_SIZE, false));
        }
        chess1.swapLocation(chess2);
        int row1 = chess1.getChessboardPoint().getX(), col1 = chess1.getChessboardPoint().getY();
        squareComponents[row1][col1] = chess1;
        int row2 = chess2.getChessboardPoint().getX(), col2 = chess2.getChessboardPoint().getY();
        squareComponents[row2][col2] = chess2;

        //只重新绘制chess1 chess2，其他不变
        chess1.repaint();
        chess2.repaint();
    }
    public boolean canMove(SquareComponent chess1, SquareComponent chess2){
        return (((Math.abs(chess1.chessboardPoint.getX() - chess2.chessboardPoint.getX()) == 1) &&
                (Math.abs(chess1.chessboardPoint.getY() - chess2.chessboardPoint.getY()) == 0))) ||
                (((Math.abs(chess1.chessboardPoint.getX() - chess2.chessboardPoint.getX()) == 0) &&
                        (Math.abs(chess1.chessboardPoint.getY() - chess2.chessboardPoint.getY()) == 1)));
    }

    /**
     * 用于比较两个棋子间的等级，能否被吃
     * @param a “吃”的发出者
     * @param b “吃”的接受者
     * @return “吃”能否生效
     */
    public boolean canEat(Level a, Level b) {
        switch (a) {
            case Bing:
                if (b == Level.Bing || b == Level.Jiang || b == Level.Blank) {
                    return true;
                } else {
                    return false;
                }
            case Ma:
                if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Blank) {
                    return true;
                } else {
                    return false;
                }
            case Che:
                if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Blank) {
                    return true;
                } else {
                    return false;
                }
            case Xiang:
                if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Blank) {
                    return true;
                } else {
                    return false;
                }
            case Shi:
                if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi || b == Level.Blank) {
                    return true;
                } else {
                    return false;
                }
            case Jiang:
                //if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi || b == Level.Jiang || b == Level.Blank) {
                if (b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi || b == Level.Jiang || b == Level.Blank) {
                    return true;
                } else {
                    return false;
                }
            case Pao:
                if (b == Level.Blank){
                    return false;
                }
                return true;
            default:
                return false;
        }
    }


    /**
     * 初始化棋盘
     */
    public void initAllChessOnBoard() {
        Random random = new Random();
        //每种类型棋子的计数器
        int cheR = 1;
        int cheB = 1;
        int jiangR = 1;
        int jiangB = 1;
        int xiangR = 1;
        int xiangB = 1;
        int maR = 1;
        int maB = 1;
        int bingR = 1;
        int bingB = 1;
        int shiR = 1;
        int shiB = 1;
        int paoR = 1;
        int paoB = 1;
        for (int i = 0; i < squareComponents.length; i++) {//squareComponents.length = 8
            for (int j = 0; j < squareComponents[i].length; j++) {//squareComponents[i].length = 4
                ChessColor color = random.nextInt(2) == 0 ? ChessColor.RED : ChessColor.BLACK;
                SquareComponent squareComponent;
                int CCR = random.nextInt(7);//随机创建棋子的随机数；
                if (CCR == 0) {
                    if (((color == ChessColor.RED) && (cheR <= 2))) {
                        squareComponent = new ChariotChessComponent(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        cheR++;
                    } else if ((color == ChessColor.BLACK) && (cheB <= 2)) {
                        squareComponent = new ChariotChessComponent(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        cheB++;
                    } else {
                        j--;
                        continue;
                    }
                } else if (CCR == 1) {
                    if (((color == ChessColor.RED) && (jiangR <= 1))) {
                        squareComponent = new JiangCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        jiangR++;
                    } else if ((color == ChessColor.BLACK) && (jiangB <= 1)) {
                        squareComponent = new JiangCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        jiangB++;
                    } else {
                        j--;
                        continue;
                    }
                } else if (CCR == 2) {
                    if (((color == ChessColor.RED) && (maR <= 2))) {
                        squareComponent = new MaCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        maR++;
                    } else if ((color == ChessColor.BLACK) && (maB <= 2)) {
                        squareComponent = new MaCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        maB++;
                    } else {
                        j--;
                        continue;
                    }
                } else if (CCR == 3) {
                    if (((color == ChessColor.RED) && (paoR <= 2))) {
                        squareComponent = new PaoCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        paoR++;
                    } else if ((color == ChessColor.BLACK) && (paoB <= 2)) {
                        squareComponent = new PaoCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        paoB++;
                    } else {
                        j--;
                        continue;
                    }
                } else if (CCR == 4) {
                    if (((color == ChessColor.RED) && (shiR <= 2))) {
                        squareComponent = new ShiChessComponent(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        shiR++;
                    } else if ((color == ChessColor.BLACK) && (shiB <= 2)) {
                        squareComponent = new ShiChessComponent(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        shiB++;
                    } else {
                        j--;
                        continue;
                    }
                } else if (CCR == 5) {
                    if (((color == ChessColor.RED) && (bingR <= 5))) {
                        squareComponent = new SoldierChessComponent(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        bingR++;
                    } else if ((color == ChessColor.BLACK) && (bingB <= 5)) {
                        squareComponent = new SoldierChessComponent(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        bingB++;
                    } else {
                        j--;
                        continue;
                    }
                } else {
                    if (((color == ChessColor.RED) && (xiangR <= 2))) {
                        squareComponent = new XiangCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        xiangR++;
                    } else if ((color == ChessColor.BLACK) && (xiangB <= 2)) {
                        squareComponent = new XiangCC(new ChessboardPoint(i, j),
                                calculatePoint(i, j), color, clickController, CHESS_SIZE,false);
                        xiangB++;
                    } else {
                        j--;
                        continue;
                    }
                }
//                squareComponent.addMouseListener(new MouseAdapter() {
//                    @Override
//                    public void mousePressed(MouseEvent e) {
//
//                    }
//
//                    @Override
//                    public void mouseReleased(MouseEvent e) {
//                    }
//
//                    @Override
//                    public void mouseEntered(MouseEvent e) {
//                        //      squareComponent.squareColor=new Color(300, 260, 199);
//                        //     squareComponent.repaint();
//                    }
//
//                    @Override
//                    public void mouseExited(MouseEvent e) {
//                        //    squareComponent.squareColor = new Color(250, 220, 190);
//
//                    }
//                });
                squareComponent.setVisible(true);
                putChessOnBoard(squareComponent);
            }
        }

    }
    public void cleanChessOfBord(){
        for (int i = 0; i < squareComponents.length; i++) {//squareComponents.length = 8
                for (int j = 0; j < squareComponents[i].length; j++) {//squareComponents[i].length = 4
                    squareComponents[i][j].setVisible(false);
                }
            }
    }
    public void putOnBoard(){
        for (int i = 0; i < squareComponents.length; i++) {
            for (int j = 0; j < squareComponents[0].length; j++) {
                squareComponents[i][j].setVisible(true);
                putChessOnBoard(squareComponents[i][j]);
            }
        }
    }
    /**
     * 绘制棋盘格子
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }

    /**
     * 将棋盘上行列坐标映射成Swing组件的Point
     *
     * @param row 棋盘上的行
     * @param col 棋盘上的列
     */
    public Point calculatePoint(int row, int col) {
        return new Point(col * CHESS_SIZE + 3, row * CHESS_SIZE + 3);
    }

    /**
     * 通过GameController调用该方法
     */
    public void loadGame(List<String> chessData) {
        String currentPlayer = chessData.get(chessData.size() - 1);
        //1.检查存档完整性
        //1.1 检查当前玩家颜色
        if (currentPlayer.equals("R")) {
            currentColor = ChessColor.RED;
        } else if (currentPlayer.equals("B")) {
            currentColor = ChessColor.BLACK;
        } else {
            JOptionPane.showMessageDialog(this, "The selected save doesn't have current player!");
            return;
        }
        //1.2 检查行数是否为8
        //1.3 检查列数是否为4
        //1.4 检查每格的字符格式是否正确

        //2.加载数据
        for (int i = 0; i < ROW_SIZE; i++) {
            char[] chars = chessData.get(i).toCharArray();
            for (int j = 0; j < COL_SIZE; j += 2) {
                char type = chars[j];
                boolean reversed = chars[j + 1] == '+';
                //Todo
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ROW_SIZE; i++) { //棋盘信息
            for (int j = 0; j < COL_SIZE; j++) {
                sb.append(squareComponents[i][j].toString());
            }
            sb.append("\n");
        }
        if (getCurrentColor() == ChessColor.RED) { //当前玩家颜色
            sb.append("R");
        } else {
            sb.append("B");
        }
        //Todo:比分信息
        return sb.toString();
    }
}
