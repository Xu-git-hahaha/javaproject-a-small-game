package Level;

/**
 * Level 用来判断棋子等级
 */
public enum Level {Bing(1,1),Ma(5,2),Che(5,3),Pao(5,4),Xiang(5,5),Shi(10,6),Jiang(30,7),Blank(0,0);
    private int point;

    public int num;

    /**
     * 用来绑定棋子等级与分数
     * @param point 对应等级棋子的分数
     */
    Level(int point, int num){
        this.point = point;
        this.num = num;
    }
    Level(int point){
        this.point = point;
    }
    public int getPoint() {
        return point;
    }

    public void setPoint(int point) {
        this.point = point;
    }


}

