import view.ChessGameFrame;
import view2.ChessGameFrame2;

import javax.swing.*;
import java.awt.event.WindowEvent;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        InitialGameFrame.initial = new InitialGameFrame(650,469);
        SwingUtilities.invokeLater(() -> {
            InitialGameFrame.initial.setVisible(true);
        });
    }
}
