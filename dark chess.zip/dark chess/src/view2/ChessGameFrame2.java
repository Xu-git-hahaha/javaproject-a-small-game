package view2;

import chessComponent2.*;
import controller.ClickController;
import controller2.ClickController2;
import controller2.GameController2;
import model2.ChessColor;
import model2.ChessboardPoint2;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.Arrays;
import java.util.Objects;


/**
 * 这个类表示游戏窗体，窗体上包含：
 * 1 Chessboard: 棋盘
 * 2 JLabel:  标签
 * 3 JButton： 按钮
 */
public class ChessGameFrame2 extends JFrame {
    public static Clip clip = null;
    private final int WIDTH;
    private final int HEIGHT;
    public final int CHESSBOARD_SIZE;
    private GameController2 gameController2;
    private static JLabel statusLabel;

    private static JLabel pointsLabel;
    public static JLabel redScoreLabel = new JLabel();
    public static JLabel blackScoreLabel = new JLabel();
    public static JLabel errormove = new JLabel("不能这么移动哟");
    public static ChessGameFrame2 CGFFF;
    //public static ChessGameFrame CGFFFF;
    public Chessboard2 chessboard2;
    //很恶心的办法，但是我没办法；
    public static Chessboard2 CB;
    //public static JLabel labelll;
    public final Icon defaultIcon = new ImageIcon("resource/image/鼠标指向前.jpg");
    public final Icon enterIcon = new ImageIcon("resource/image/指向后.jpg");
    private final Icon pressedIcon = new ImageIcon("resource/image/点击后.jpg");
    private final Icon defaultSoundIcon = new ImageIcon("resource/image/开声音.jpg");
    private final Icon closeSoundIcon = new ImageIcon("resource/image/关声音.jpg");
    public static ImageIcon img = new ImageIcon();//这是背景图片
    public static JLabel imgLabel = new JLabel();//将背景图放在标签里。
    public static JButton musicbutton = new JButton();

    enum Name {
        Che___,Shi___,Bing__,Ma____,Jiang_,Xiang_,Pao___,______
    }
    public void background(String str){
        //加入背景图片
        img = null;
        imgLabel.setVisible(false);
        img = new ImageIcon("resource/image/"+ str +".png");//这是背景图片
        img.setImage(img.getImage().getScaledInstance(this.WIDTH, this.HEIGHT, Image.SCALE_DEFAULT));
//        JLabel imgLabel = new JLabel(img);//将背景图放在标签里。
        imgLabel = new JLabel(img);
        getLayeredPane().add(imgLabel, Integer.valueOf(Integer.MIN_VALUE));//注意这里是关键，将背景标签添加到jfram的LayeredPane面板里。
        imgLabel.setBounds(0, 0, WIDTH, HEIGHT);//设置背景标签的位置
        imgLabel.repaint();
        imgLabel.setVisible(true);
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        ((JPanel) cp).setOpaque(false);

    }
    public ChessGameFrame2(int width, int height) {
        setTitle("一个好玩的 Dark ♂ chess"); //设置标题
        this.WIDTH = width;
        this.HEIGHT = height;
        this.CHESSBOARD_SIZE = HEIGHT * 4 / 5;


//        //加入背景图片
//        ImageIcon img = new ImageIcon("resource/image/背景1(1).png");//这是背景图片
//        img.setImage(img.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT));
//        JLabel imgLabel = new JLabel(img);//将背景图放在标签里。
//        getLayeredPane().add(imgLabel, Integer.valueOf(Integer.MIN_VALUE));//注意这里是关键，将背景标签添加到jfram的LayeredPane面板里。
//        imgLabel.setBounds(0, 0, WIDTH, HEIGHT);//设置背景标签的位置
//        Container cp = getContentPane();
//        cp.setLayout(new BorderLayout());
//        ((JPanel) cp).setOpaque(false);
        background("背景1(1)");


        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null); // Center the window.
        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //设置程序关闭按键，如果点击右上方的叉就游戏全部关闭了
        //setDefaultCloseOperation(ClickController.n);
        setLayout(null);

        CB = addChessboard();
        addLabel();
        addHelloButton();
        addLoadButton();
        addSaveButton();
        addRestartButton();
        addExitButton();
        addSoundControlButton();
        add666Button();
        addRedScoreLabel();
        addBlackScoreLabel();
        addJMenubar();


//        //进入游戏时播放BGM
//        try {
//            Clip clip = AudioSystem.getClip();
//            clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/20221126_022814转换格式.wav")));
//            clip.loop(Clip.LOOP_CONTINUOUSLY);
//        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
//            e.printStackTrace();
//        }
    }

    public JMenuBar addJMenubar (){
        //set music menu
        JMenuBar jmenubar = new JMenuBar();
        JMenu changemusic = new JMenu("背景音乐");
        JMenu changebackgroundpaint = new JMenu("背景图片");
        JMenu guanyuwomen = new JMenu("关于我们");

        JMenuItem zuiweidadezuopin = new JMenuItem("最伟大的作品-周杰伦");
        JMenuItem keainvren = new JMenuItem("可爱女人-周杰伦");
        JMenuItem huahai = new JMenuItem("花海-周杰伦");
        JMenuItem minemine = new JMenuItem("Mine Mine-周杰伦");
        JMenuItem qianlizhiwai = new JMenuItem("千里之外-周杰伦");

        JMenuItem tupian1 = new JMenuItem("背景1");
        JMenuItem tupian2 = new JMenuItem("背景2");
        JMenuItem tupian3 = new JMenuItem("背景3");

        JMenuItem womendeqq1 = new JMenuItem("QQ:2068438826");
        JMenuItem womendeqq2 = new JMenuItem("QQ:505314385");

        guanyuwomen.add(womendeqq1);
        guanyuwomen.add(womendeqq2);

        changemusic.add(zuiweidadezuopin);
        changemusic.add(keainvren);
        changemusic.add(huahai);
        changemusic.add(minemine);
        changemusic.add(qianlizhiwai);

        changebackgroundpaint.add(tupian1);
        changebackgroundpaint.add(tupian2);
        changebackgroundpaint.add(tupian3);

        jmenubar.add(changemusic);
        jmenubar.add(changebackgroundpaint);
        jmenubar.add(guanyuwomen);

        this.setJMenuBar(jmenubar);

        this.setVisible(true);

        zuiweidadezuopin.addActionListener(e ->{
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("最伟大的作品");
        });
        keainvren.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("可爱女人");
        });
        huahai.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("花海");
        });
        minemine.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("Mine Mine");
        });
        qianlizhiwai.addActionListener(e -> {
            clip.stop();
            musicbutton.setIcon(defaultSoundIcon);
            sounddddd("千里之外");
        });

        tupian1.addActionListener(e -> {
            background("背景1(1)");
        });
        tupian2.addActionListener(e -> {
            System.out.println("wevgbksj");
            background("背景222(1)");
        });
        tupian3.addActionListener(e -> {
            background("背景333(1)");
        });

        return jmenubar;
    }

    /**
     * 在游戏窗体中添加棋盘
     */
    private Chessboard2 addChessboard() {
        Chessboard2 chessboard2 = new Chessboard2(CHESSBOARD_SIZE / 2, CHESSBOARD_SIZE);
        gameController2 = new GameController2(chessboard2);
        //************************!!!!!!!!!!!!!!!!!!!!!!!!!
        chessboard2.setLocation(HEIGHT / 6, HEIGHT / 10);
        add(chessboard2);
        this.chessboard2 = chessboard2;
        return chessboard2;
    }

    /**
     * 在游戏窗体中添加标签
     */
    private void addLabel() {
        statusLabel = new JLabel("Yours turn");
        statusLabel.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 35);
        statusLabel.setSize(250, 60);
        statusLabel.setFont(new Font("Rock", Font.BOLD, 15));
        add(statusLabel);
        //return statusLabel;
    }

    //  protected void addRedScore(Graphics redScore) {
//        redScore.setColor(Color.RED);
//        redScore.setFont(new Font());
//       // redScore.setFont(Rock);
//    }
    public void addRedScoreLabel() {
//        String str1 = "红方：" + 0 + "分";
//        redScoreLabel.setText(str1);
        //       redScoreLabel = new JLabel("红方：" + 0 + "分");
        redScoreLabel.setText("红方：" + 0 + "分");
        redScoreLabel.setLocation(WIDTH * 42 / 50 - 20, HEIGHT * 13 / 200 - 16);
        redScoreLabel.setSize(250, 70);
        redScoreLabel.setFont(new Font("Rock", Font.BOLD, 25));
        add(redScoreLabel);
    }

    public void addBlackScoreLabel() {
        //BlackScoreLabel = new JLabel("黑方：" + 0 + "分");
        // redScoreLabel.setText("shabi");
        blackScoreLabel.setText("黑方AI：" + 0 + "分");
        blackScoreLabel.setLocation(WIDTH * 42 / 50 - 20, HEIGHT * 2 / 200 - 16);
        blackScoreLabel.setSize(250, 70);
        blackScoreLabel.setFont(new Font("Rock", Font.BOLD, 25));
        add(blackScoreLabel);
    }


    public static JLabel getStatusLabel() {
        return statusLabel;
    }

    /**
     * 在游戏窗体中增加一个按钮，如果按下的话就会显示Hello, world!
     */

    private void add666Button() {
        JButton button = new JButton("666");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setLocation(WIDTH * 4 / 5 + 80, HEIGHT * 4 / 5);
        button.setSize(70, 50);
        button.setFont(new Font("Rock", Font.BOLD, 18));
        add(button);
        int arri[][] = new int[8][4];
        //int arr2[] = new int[4];
//        for (int i = 0; i < arri.length; i++) {
//            for (int i1 = 0; i1 < arri[i].length; i1++) {
//                arri[i][i1] = -999;
//            }
//        }
        //加入鼠标监听
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                for (int i = 0; i < arri.length; i++) {
                    for (int i1 = 0; i1 < arri[i].length; i1++) {
                        arri[i][i1] = -999;
                    }
                }
                button.setIcon(pressedIcon);
                for (int i = 0; i < chessboard2.squareComponent2s.length; i++) {
                    for (int i1 = 0; i1 < chessboard2.squareComponent2s[i].length; i1++) {
                        if (!chessboard2.squareComponent2s[i][i1].isReversal) {
                            chessboard2.squareComponent2s[i][i1].setReversal(true);
                            //          chessboard.squareComponents[i][i1].draw;
                            chessboard2.squareComponent2s[i][i1].repaint();
                            arri[i][i1] = 9;
                        }
                    }
                }

            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
                for (int i = 0; i < arri.length; i++) {
                    for (int i1 = 0; i1 < arri[i].length; i1++) {
                        if (arri[i][i1] != -999) {
                            chessboard2.squareComponent2s[i][i1].setReversal(false);
                            chessboard2.squareComponent2s[i][i1].repaint();
                        }
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

    private void addHelloButton() {
        JButton button = new JButton("Hello");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);


        button.addActionListener(e -> JOptionPane.showMessageDialog(this, "达咩~不要点我哟~"));
        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 120 - 25);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        add(button);

        //加入鼠标监听
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //有时间了可以做得更好
                //JOptionPane.showMessageDialog(null, "达咩~不要点我哟~");
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
                try {
                    wait(100);
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }


    //
    //
//    private final Icon defaultIcon = new ImageIcon("resource/image/BA{EPQQ33]JD@M(1NVM[VAT.png");
//    private final Icon enterIcon = new ImageIcon("C:\\Users\\许国祥\\Desktop\\123456\\resource\\image\\b5c6b66b652dfd4646e70630aba9ec5a.jpeg");
//    private final Icon pressedIcon = new ImageIcon("C:\\Users\\许国祥\\Desktop\\123456\\resource\\image\\9893542a158de888a252c246aa76add9.jpeg");
    private void addLoadButton() {
        JButton button = new JButton("Load");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);


        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 240 - 25 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rockwell", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);

        button.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser("./resource") {{//设置默认路径
                setSelectedFile(new File("save.txt"));//设置默认文件名
//                setFileFilter(new FileNameExtensionFilter("*.txt", "txt"));//设置文件过滤器
            }};
            int res = fileChooser.showOpenDialog(this);
            if (res == JFileChooser.APPROVE_OPTION) {//如果点击了“确认”
                if (Objects.equals(fileChooser.getTypeDescription(fileChooser.getSelectedFile()), "文本文档")){//判断文件类型是否为“文本文档”
                    label:
                    try {
                        FileReader fileReader = new FileReader(fileChooser.getSelectedFile());
                        BufferedReader reader = new BufferedReader(fileReader);
                        String line = reader.readLine();
                        String[] getSaveStr = line.replace("[", "").replace("]", "").split(", ");
                        //在这里写方法遍历s中的每一项
                        if (getSaveStr.length >= 32) {
                            for (int i = 0; i < 32; i++) {
                                if (getSaveStr[i].equals("RED_____") || getSaveStr[i].equals("BLACK___")) {
                                    JOptionPane.showMessageDialog(null, "The wrong size of chessboard.","Errol Type : 102", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                } else if (!(getSaveStr[i].charAt(6) == 'R' || getSaveStr[i].charAt(6) == 'B' || getSaveStr[i].substring(6, 8).equals("__"))){
                                    JOptionPane.showMessageDialog(null, "The wrong type of chess.","Errol Type : 103", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                } else if (getSaveStr[i].charAt(7) != '+' && getSaveStr[i].charAt(7) != '-' && !getSaveStr[i].substring(6, 8).equals("__")) {
                                    JOptionPane.showMessageDialog(null, "The wrong type of chess.","Errol Type : 103", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                } else if (!Arrays.toString(Name.values()).contains(getSaveStr[i].substring(0, 6))) {
                                    JOptionPane.showMessageDialog(null, "The wrong type of chess.","Errol Type : 103", JOptionPane.PLAIN_MESSAGE);
                                    break label;
                                }
                            }
                            if (!getSaveStr[32].equals("RED_____") && !getSaveStr[32].equals("BLACK___")){
                                JOptionPane.showMessageDialog(null, "Lack of current color.","Errol Type : 104", JOptionPane.PLAIN_MESSAGE);
                                break label;
                            }
                            SquareComponent2[][] sc = chessboard2.squareComponent2s;
                            //chessboard.setVisible(false);
                            //chessboard = new Chessboard(CHESSBOARD_SIZE / 2, CHESSBOARD_SIZE, chessboard.squareComponents);
                            chessboard2 = CB;
                            gameController2 = new GameController2(chessboard2);
                            chessboard2.setLocation(HEIGHT / 6, HEIGHT / 10);
                            add(chessboard2);
                            //this.chessboard = chessboard;

                            //***********************************
                            ClickController2.setEatenIndex();
                            ClickController2.BlackPoint = 0;
                            ClickController2.RedPoint = 0;

                            ClickController2 ccc = chessboard2.clickController2;
                            for (int i = 0; i < 32; i++) {
                                sc[i / 4][i % 4].setVisible(false);
                                //当前棋子的红黑方：
                                ChessColor dangqianqizidehongheifang = ChessColor.BLACK;
                                //当前棋子的坐标：
                                ChessboardPoint2 qizidezuobiao = new ChessboardPoint2(i / 4, i % 4);
                                //当前棋子是否翻转
                                Boolean reversalllll = false;
                                switch (getSaveStr[i].charAt(6)) {
                                    case 'R':
                                        dangqianqizidehongheifang = ChessColor.RED;
                                        break;
                                    case 'B':
                                        dangqianqizidehongheifang = ChessColor.BLACK;
                                        break;
                                }
                                switch (getSaveStr[i].charAt(7)) {
                                    case '+':
                                        reversalllll = true;
                                        break;
                                    case '-':
                                        reversalllll = false;
                                        break;
                                }
                                String getSubStr = getSaveStr[i].substring(0, 6);

                                //对于不同的substring，进行判断，之后new一个判断出来的对象（与 Load 一致）以覆盖现有对象；
                                switch (getSubStr) {
                                    case "Che___":
                                        ChariotChessComponent222 current = new ChariotChessComponent222(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard2.CHESS_SIZE, reversalllll);
                                        sc[i / 4][i % 4] = null;
                                        sc[i / 4][i % 4] = current;
                                        break;
                                    case "Jiang_":
                                        sc[i / 4][i % 4] = new JiangCC2(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard2.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Ma____":
                                        sc[i / 4][i % 4] = new MaCC2(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard2.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Pao___":
                                        sc[i / 4][i % 4] = new PaoCC2(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard2.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Shi___":
                                        sc[i / 4][i % 4] = new ShiChessComponent22(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard2.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Bing__":
                                        sc[i / 4][i % 4] = new SoldierChessComponent22(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard2.CHESS_SIZE, reversalllll);
                                        break;
                                    case "Xiang_":
                                        sc[i / 4][i % 4] = new XiangCC2(qizidezuobiao, sc[i / 4][i % 4].getLocation(), dangqianqizidehongheifang, ccc, chessboard2.CHESS_SIZE, reversalllll);
                                        break;
                                    case "______":
                                        sc[i / 4][i % 4] = new EmptySlotComponent22(qizidezuobiao, sc[i / 4][i % 4].getLocation(), ccc, chessboard2.CHESS_SIZE, true);
                                        System.out.println("111");
                                        break;
                                }
                                sc[i / 4][i % 4].repaint();
                                sc[i / 4][i % 4].setVisible(true);

                            }
                            //sc[0][0]=new ChariotChessComponent();
                            System.out.println(Arrays.toString(getSaveStr));
                            chessboard2.putOnBoard();
                            if (Objects.equals(getSaveStr[32], "RED_____")) {
                                chessboard2.setCurrentColor(ChessColor.RED);
                                ChessGameFrame2.getStatusLabel().setText(String.format("%s's TURN", chessboard2.currentColor));
                            } else if (Objects.equals(getSaveStr[32], "BLACK___")) {
                                chessboard2.setCurrentColor(ChessColor.BLACK);
                                ChessGameFrame2.getStatusLabel().setText(String.format("%s's TURN", chessboard2.currentColor));
                            } else {
                               // ClickController.rev = 0;
                                ChessGameFrame2.getStatusLabel().setText("Click to decide whose turn");
                            }
                            if (getSaveStr[33].charAt(1) == '_') {
                                ClickController2.BlackPoint = getSaveStr[33].charAt(0) - 48;
                                ChessGameFrame2.blackScoreLabel.setText("黑方AI：" + ClickController2.BlackPoint + "分");
                            } else {
                                ClickController2.BlackPoint = (getSaveStr[33].charAt(0) - 48) * 10 + getSaveStr[33].charAt(1) - 48;
                                ChessGameFrame2.blackScoreLabel.setText("黑方AI：" + ClickController2.BlackPoint + "分");
                            }
                            if (getSaveStr[34].charAt(1) == '_') {
                                ClickController2.RedPoint = getSaveStr[34].charAt(0) - 48;
                                ChessGameFrame2.redScoreLabel.setText("红方：" + ClickController2.RedPoint + "分");
                            } else {
                                ClickController2.RedPoint = (getSaveStr[34].charAt(0) - 48) * 10 + getSaveStr[34].charAt(1) - 48;
                                ChessGameFrame2.redScoreLabel.setText("红方：" + ClickController2.RedPoint + "分");
                            }
                            ClickController2.bbche = getSaveStr[35].charAt(0) - 48 - 1;
                            ClickController2.rrche = getSaveStr[36].charAt(0) - 48 - 1;
                            ClickController2.bbjiang = getSaveStr[37].charAt(0) - 48 - 1;
                            ClickController2.rrjiang = getSaveStr[38].charAt(0) - 48 - 1;
                            ClickController2.bbma = getSaveStr[39].charAt(0) - 48 - 1;
                            ClickController2.rrma = getSaveStr[40].charAt(0) - 48 - 1;
                            ClickController2.bbpao = getSaveStr[41].charAt(0) - 48 - 1;
                            ClickController2.rrpao = getSaveStr[42].charAt(0) - 48 - 1;
                            ClickController2.bbshi = getSaveStr[43].charAt(0) - 48 - 1;
                            ClickController2.rrshi = getSaveStr[44].charAt(0) - 48 - 1;
                            ClickController2.bbbing = getSaveStr[45].charAt(0) - 48 - 1;
                            ClickController2.rrbing = getSaveStr[46].charAt(0) - 48 - 1;
                            ClickController2.bbxiang = getSaveStr[47].charAt(0) - 48 - 1;
                            ClickController2.rrxiang = getSaveStr[48].charAt(0) - 48 - 1;
                            if (ClickController2.bbche == 0) {
                                ClickController2.jLabel1.setIcon(ClickController2.bche1);
                                ClickController2.jLabel1.setLocation(57 - 10 * ClickController2.bbche, 85);
                                ClickController2.jLabel1.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel1);
                                ClickController2.jLabel1.repaint();
                                ClickController2.bbche = ClickController2.bbche + 1;
                            } else if (ClickController2.bbche == 1) {
                                ClickController2.jLabel1.setIcon(ClickController2.bche2);
                                ClickController2.jLabel1.setLocation(57 - 10 * ClickController2.bbche, 85);
                                ClickController2.jLabel1.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel1);
                                ClickController2.jLabel1.repaint();
                                ClickController2.bbche = ClickController2.bbche + 1;
                            }

                            if (ClickController2.rrche == 0) {
                                ClickController2.jLabel2.setIcon(ClickController2.rche1);
                                ClickController2.jLabel2.setLocation(435 + 10 * ClickController2.rrche, 85);
                                ClickController2.jLabel2.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel2);
                                ClickController2.jLabel2.repaint();
                                ClickController2.rrche = ClickController2.rrche + 1;
                            } else if (ClickController2.rrche == 1) {
                                ClickController2.jLabel2.setIcon(ClickController2.rche2);
                                ClickController2.jLabel2.setLocation(435 + 10 * ClickController2.rrche, 85);
                                ClickController2.jLabel2.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel2);
                                ClickController2.jLabel2.repaint();
                                ClickController2.rrche = ClickController2.rrche + 1;
                            }
                            if (ClickController2.bbma == 0) {
                                ClickController2.jLabel4.setIcon(ClickController2.bma1);
                                ClickController2.jLabel4.setLocation(57 - 10 * ClickController2.bbma, 85 + 68 * 1);
                                ClickController2.jLabel4.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel4);
                                ClickController2.jLabel4.repaint();
                                ClickController2.bbma = ClickController2.bbma + 1;
                            } else if (ClickController2.bbma == 1) {
                                ClickController2.jLabel4.setIcon(ClickController2.bma2);
                                ClickController2.jLabel4.setLocation(57 - 10 * ClickController2.bbma, 85 + 68 * 1);
                                ClickController2.jLabel4.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel4);
                                ClickController2.jLabel4.repaint();
                                ClickController2.bbma = ClickController2.bbma + 1;
                            }

                            if (ClickController2.rrma == 0) {
                                ClickController2.jLabel3.setIcon(ClickController2.rma1);
                                ClickController2.jLabel3.setLocation(435 + 10 * ClickController2.rrma, 85 + 68 * 1);
                                ClickController2.jLabel3.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel3);
                                ClickController2.jLabel3.repaint();
                                ClickController2.rrma = ClickController2.rrma + 1;
                            } else if (ClickController2.rrma == 1) {
                                ClickController2.jLabel3.setIcon(ClickController2.rma2);
                                ClickController2.jLabel3.setLocation(435 + 10 * ClickController2.rrma, 85 + 68 * 1);
                                ClickController2.jLabel3.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel3);
                                ClickController2.jLabel3.repaint();
                                ClickController2.rrma = ClickController2.rrma + 1;

                            }

                            if (ClickController2.bbpao == 0) {
                                ClickController2.jLabel5.setIcon(ClickController2.bpao1);
                                ClickController2.jLabel5.setLocation(57 - 10 * ClickController2.bbpao, 85 + 68 * 2);
                                ClickController2.jLabel5.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel5);
                                ClickController2.jLabel5.repaint();
                                ClickController2.bbpao = ClickController2.bbpao + 1;
                            } else if (ClickController2.bbpao == 1) {
                                ClickController2.jLabel5.setIcon(ClickController2.bpao2);
                                ClickController2.jLabel5.setLocation(57 - 10 * ClickController2.bbpao, 85 + 68 * 2);
                                ClickController2.jLabel5.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel5);
                                ClickController2.jLabel5.repaint();
                                ClickController2.bbpao = ClickController2.bbpao + 1;
                            }

                            if (ClickController2.rrpao == 0) {
                                ClickController2.jLabel6.setIcon(ClickController2.rpao1);
                                ClickController2.jLabel6.setLocation(435 + 10 * ClickController2.rrpao, 85 + 68 * 2);
                                ClickController2.jLabel6.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel6);
                                ClickController2.jLabel6.repaint();
                                ClickController2.rrpao = ClickController2.rrpao + 1;
                            } else if (ClickController2.rrpao == 1) {
                                ClickController2.jLabel6.setIcon(ClickController2.rpao2);
                                ClickController2.jLabel6.setLocation(435 + 10 * ClickController2.rrpao, 85 + 68 * 2);
                                ClickController2.jLabel6.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel6);
                                ClickController2.jLabel6.repaint();
                                ClickController2.rrpao = ClickController2.rrpao + 1;
                            }


                            if (ClickController2.bbshi == 0) {
                                ClickController2.jLabel7.setIcon(ClickController2.bshi1);
                                ClickController2.jLabel7.setLocation(57 - 10 * ClickController2.bbshi, 85 + 68 * 3);
                                ClickController2.jLabel7.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel7);
                                ClickController2.jLabel7.repaint();
                                ClickController2.bbshi = ClickController2.bbshi + 1;
                            } else if (ClickController2.bbshi == 1) {
                                ClickController2.jLabel7.setIcon(ClickController2.bshi2);
                                ClickController2.jLabel7.setLocation(57 - 10 * ClickController2.bbshi, 85 + 68 * 3);
                                ClickController2.jLabel7.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel7);
                                ClickController2.jLabel7.repaint();
                                ClickController2.bbshi = ClickController2.bbshi + 1;
                            }

                            if (ClickController2.rrshi == 0) {
                                ClickController2.jLabel8.setIcon(ClickController2.rshi1);
                                ClickController2.jLabel8.setLocation(435 + 10 * ClickController2.rrshi, 85 + 68 * 3);
                                ClickController2.jLabel8.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel8);
                                ClickController2.jLabel8.repaint();
                                ClickController2.rrshi = ClickController2.rrshi + 1;
                            } else if (ClickController2.rrshi == 1) {
                                ClickController2.jLabel8.setIcon(ClickController2.rshi2);
                                ClickController2.jLabel8.setLocation(435 + 10 * ClickController2.rrshi, 85 + 68 * 3);
                                ClickController2.jLabel8.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel8);
                                ClickController2.jLabel8.repaint();
                                ClickController2.rrshi = ClickController2.rrshi + 1;
                            }

                            if (ClickController2.bbbing == 0) {
                                ClickController2.jLabel9.setIcon(ClickController2.bbing1);
                                ClickController2.jLabel9.setLocation(57 - 10 * ClickController2.bbbing, 85 + 68 * 4);
                                ClickController2.jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel9);
                                ClickController2.jLabel9.repaint();
                                ClickController2.bbbing = ClickController2.bbbing + 1;
                            } else if (ClickController2.bbbing == 1) {
                                ClickController2.jLabel9.setIcon(ClickController2.bbing2);
                                ClickController2.jLabel9.setLocation(57 - 10 * ClickController2.bbbing, 85 + 68 * 4);
                                ClickController2.jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel9);
                                ClickController2.jLabel9.repaint();
                                ClickController2.bbbing = ClickController2.bbbing + 1;
                            } else if (ClickController2.bbbing == 2) {
                                ClickController2.jLabel9.setIcon(ClickController2.bbing3);
                                ClickController2.jLabel9.setLocation(57 - 10 * ClickController2.bbbing, 85 + 68 * 4);
                                ClickController2.jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel9);
                                ClickController2.jLabel9.repaint();
                                ClickController2.bbbing = ClickController2.bbbing + 1;
                            } else if (ClickController2.bbbing == 3) {
                                ClickController2.jLabel9.setIcon(ClickController2.bbing4);
                                ClickController2.jLabel9.setLocation(57 - 10 * ClickController2.bbbing, 85 + 68 * 4);
                                ClickController2.jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel9);
                                ClickController2.jLabel9.repaint();
                                ClickController2.bbbing = ClickController2.bbbing + 1;
                            } else if (ClickController2.bbbing == 4) {
                                ClickController2.jLabel9.setIcon(ClickController2.bbing5);
                                ClickController2.jLabel9.setLocation(57 - 10 * ClickController2.bbbing, 85 + 68 * 4);
                                ClickController2.jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel9);
                                ClickController2.jLabel9.repaint();
                                ClickController2.bbbing = ClickController2.bbbing + 1;
                            }

                            if (ClickController2.rrbing == 0) {
                                ClickController2.jLabel10.setIcon(ClickController2.rbing1);
                                ClickController2.jLabel10.setLocation(435 + 10 * ClickController2.rrbing, 85 + 68 * 4);
                                ClickController2.jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel10);
                                ClickController2.jLabel10.repaint();
                                ClickController2.rrbing = ClickController2.rrbing + 1;
                            } else if (ClickController2.rrbing == 1) {
                                ClickController2.jLabel10.setIcon(ClickController2.rbing2);
                                ClickController2.jLabel10.setLocation(435 + 10 * ClickController2.rrbing, 85 + 68 * 4);
                                ClickController2.jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel10);
                                ClickController2.jLabel10.repaint();
                                ClickController2.rrbing = ClickController2.rrbing + 1;
                            } else if (ClickController2.rrbing == 2) {
                                ClickController2.jLabel10.setIcon(ClickController2.rbing3);
                                ClickController2.jLabel10.setLocation(435 + 10 * ClickController2.rrbing, 85 + 68 * 4);
                                ClickController2.jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel10);
                                ClickController2.jLabel10.repaint();
                                ClickController2.rrbing = ClickController2.rrbing + 1;
                            } else if (ClickController2.rrbing == 3) {
                                ClickController2.jLabel10.setIcon(ClickController2.rbing4);
                                ClickController2.jLabel10.setLocation(435 + 10 * ClickController2.rrbing, 85 + 68 * 4);
                                ClickController2.jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel10);
                                ClickController2.jLabel10.repaint();
                                ClickController2.rrbing = ClickController2.rrbing + 1;

                            } else if (ClickController2.rrbing == 4) {
                                ClickController2.jLabel10.setIcon(ClickController2.rbing5);
                                ClickController2.jLabel10.setLocation(435 + 10 * ClickController2.rrbing, 85 + 68 * 4);
                                ClickController2.jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel10);
                                ClickController2.jLabel10.repaint();
                                ClickController2.rrbing = ClickController2.rrbing + 1;
                            }

                            if (ClickController2.bbxiang == 0) {
                                ClickController2.jLabel11.setIcon(ClickController2.bxiang1);
                                ClickController2.jLabel11.setLocation(57 - 10 * ClickController2.bbxiang, 85 + 68 * 5);
                                ClickController2.jLabel11.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel11);
                                ClickController2.jLabel11.repaint();
                                ClickController2.bbxiang = ClickController2.bbxiang + 1;
                            } else if (ClickController2.bbxiang == 1) {
                                ClickController2.jLabel11.setIcon(ClickController2.bxiang2);
                                ClickController2.jLabel11.setLocation(57 - 10 * ClickController2.bbxiang, 85 + 68 * 5);
                                ClickController2.jLabel11.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel11);
                                ClickController2.jLabel11.repaint();
                                ClickController2.bbxiang = ClickController2.bbxiang + 1;
                            }

                            if (ClickController2.rrxiang == 0) {
                                ClickController2.jLabel12.setIcon(ClickController2.rxiang1);
                                ClickController2.jLabel12.setLocation(435 + 10 * ClickController2.rrxiang, 85 + 68 * 5);
                                ClickController2.jLabel12.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel12);
                                ClickController2.jLabel12.repaint();
                                ClickController2.rrxiang = ClickController2.rrxiang + 1;
                            } else if (ClickController2.rrxiang == 1) {
                                ClickController2.jLabel12.setIcon(ClickController2.rxiang2);
                                ClickController2.jLabel12.setLocation(435 + 10 * ClickController2.rrxiang, 85 + 68 * 5);
                                ClickController2.jLabel12.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel12);
                                ClickController2.jLabel12.repaint();
                                ClickController2.rrxiang = ClickController2.rrxiang + 1;
                            }

                            if (ClickController2.bbjiang == 0) {
                                ClickController2.jLabel13.setIcon(ClickController2.bjiang1);
                                ClickController2.jLabel13.setLocation(57 - 10 * ClickController2.bbjiang, 85 + 68 * 6);
                                ClickController2.jLabel13.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel13);
                                ClickController2.jLabel13.repaint();
                                ClickController2.bbjiang = ClickController2.bbjiang + 1;
                            }

                            if (ClickController2.rrxiang == 0) {
                                ClickController2.jLabel14.setIcon(ClickController2.rjiang1);
                                ClickController2.jLabel14.setLocation(435 + 10 * ClickController2.rrxiang, 85 + 68 * 6);
                                ClickController2.jLabel14.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(ClickController2.jLabel14);
                                ClickController2.jLabel14.repaint();
                                ClickController2.rrjiang = ClickController2.rrjiang + 1;
                            }

                            ClickController2.bbche ++;
                            ClickController2.rrche ++;
                            ClickController2.bbjiang ++;
                            ClickController2.rrjiang ++;
                            ClickController2.bbma ++;
                            ClickController2.rrma ++;
                            ClickController2.bbpao ++;
                            ClickController2.rrpao ++;
                            ClickController2.bbshi ++;
                            ClickController2.rrshi ++;
                            ClickController2.bbbing ++;
                            ClickController2.rrbing ++;
                            ClickController2.bbxiang ++;
                            ClickController2.rrxiang ++;

                            reader.close();
                            fileReader.close();
                        } else {
                            JOptionPane.showMessageDialog(null, " The wrong size of chessboard.","Error Type : 102", JOptionPane.PLAIN_MESSAGE);
                        }
                    }catch (Exception ee) {
                        ee.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "The wrong type of file.","Error Type : 101", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });


//        //加入鼠标监听
//        MouseListener loadBottonMouseListener = new MouseListener() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//                button.setIcon(pressedIcon);
//            }
//
//            @Override
//            public void mousePressed(MouseEvent e) {
//                button.setIcon(pressedIcon);
//            }
//
//            @Override
//            public void mouseReleased(MouseEvent e) {
//                button.setIcon(enterIcon);
//            }
//
//            @Override
//            public void mouseEntered(MouseEvent e) {
//                button.setIcon(enterIcon);
//            }
//
//            @Override
//            public void mouseExited(MouseEvent e) {
//                button.setIcon(defaultIcon);
//            }
//        };

        //加入鼠标监听
        button.addMouseListener(new

                                        MouseListener() {
                                            @Override
                                            public void mouseClicked(MouseEvent e) {
                                                button.setIcon(pressedIcon);
                                            }

                                            @Override
                                            public void mousePressed(MouseEvent e) {
                                                button.setIcon(pressedIcon);
                                            }

                                            @Override
                                            public void mouseReleased(MouseEvent e) {
                                                button.setIcon(enterIcon);
                                            }

                                            @Override
                                            public void mouseEntered(MouseEvent e) {
                                                button.setIcon(enterIcon);
                                            }

                                            @Override
                                            public void mouseExited(MouseEvent e) {
                                                button.setIcon(defaultIcon);
                                            }
                                        });

    }


    private void addSaveButton() {
        JButton button = new JButton("Save");

        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);


        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 360 - 25 - 15 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);

        button.addActionListener(action -> {
            JFileChooser fileChooser = new JFileChooser("./resource") {{//设置默认路径
                setSelectedFile(new File("save.txt"));//设置默认文件名
                setFileFilter(new FileNameExtensionFilter("*.txt", "txt"));//设置文件过滤器
            }};
            String[] s = new String[49];
            int res = fileChooser.showSaveDialog(this);
            if (res == JFileChooser.APPROVE_OPTION) {//如果点击了“保存”
                try (FileWriter writer = new FileWriter(fileChooser.getSelectedFile())) {
                    int i = 0;
                    for (SquareComponent2[] a : chessboard2.squareComponent2s) {
                        for (SquareComponent2 b : a) {
                            s[i] = b.toString();
                            i++;
                        }
                    }
                    s[32] = chessboard2.currentcolorToString();
                    if (ClickController2.BlackPoint < 10) {
                        s[33] = ClickController2.BlackPoint + "______B";
                    } else {
                        s[33] = ClickController2.BlackPoint + "_____B";
                    }
                    if (ClickController2.RedPoint < 10) {
                        s[34] = ClickController2.RedPoint + "______R";
                    } else {
                        s[34] = ClickController2.RedPoint + "_____R";
                    }
                    int eatenarr[] = new int[14];
                    eatenarr[0] = ClickController2.bbche;
                    eatenarr[1] = ClickController2.rrche;
                    eatenarr[2] = ClickController2.bbjiang;
                    eatenarr[3] = ClickController2.rrjiang;
                    eatenarr[4] = ClickController2.bbma;
                    eatenarr[5] = ClickController2.rrma;
                    eatenarr[6] = ClickController2.bbpao;
                    eatenarr[7] = ClickController2.rrpao;
                    eatenarr[8] = ClickController2.bbshi;
                    eatenarr[9] = ClickController2.rrshi;
                    eatenarr[10] = ClickController2.bbbing;
                    eatenarr[11] = ClickController2.rrbing;
                    eatenarr[12] = ClickController2.bbxiang;
                    eatenarr[13] = ClickController2.rrxiang;
                    for (int i1 = 0; i1 < eatenarr.length; i1++) {
                        s[i1 + 35] = eatenarr[i1] + "____EEE";
                    }
                    writer.write(Arrays.toString(s));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //加入鼠标监听；
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });

    }

    public void addRestartButton() {
        JButton button = new JButton("Restart");
        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 480 - 25 - 15 - 15 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);
        button.addActionListener(action -> {
            int n2 = JOptionPane.showConfirmDialog(null, "是否重新开始？", "", JOptionPane.YES_NO_OPTION);
            if (n2 == 0) {
                ClickController2.setEatenIndex();
                ClickController2.BlackPoint = 0;
                ClickController2.RedPoint = 0;
             //   ClickController.rev = 0;
                ChessGameFrame2.blackScoreLabel.setText("黑方AI：" + ClickController2.BlackPoint + "分");
                ChessGameFrame2.redScoreLabel.setText("红方：" + ClickController2.RedPoint + "分");
                ChessGameFrame2.CB.cleanChessOfBord();
                ChessGameFrame2.CB.initAllChessOnBoard();
                ChessGameFrame2.getStatusLabel().setText("Yours turn");
            }
        });
        //加入鼠标监听；
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

    public void addExitButton() {
        JButton button = new JButton("Exit");
        //给按钮设置默认背景颜色
        button.setIcon(defaultIcon);
        //使按钮的字一直位于上方和中央
        button.setVerticalTextPosition(SwingConstants.CENTER);
        button.setHorizontalTextPosition(SwingConstants.CENTER);
        button.setLocation(WIDTH * 3 / 5, HEIGHT / 10 + 600 - 25 - 15 - 15 - 15 - 15);
        button.setSize(180, 60);
        button.setFont(new Font("Rock", Font.BOLD, 20));
        button.setBackground(Color.LIGHT_GRAY);
        add(button);
        button.addActionListener(action -> {
            int n3 = JOptionPane.showConfirmDialog(null, "是否退出？", "", JOptionPane.YES_NO_OPTION);
            if (n3 == 0) {
                CGFFF.dispatchEvent(new WindowEvent(CGFFF, WindowEvent.WINDOW_CLOSING));
            }
        });
        //加入鼠标监听；
        button.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setIcon(pressedIcon);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                button.setIcon(enterIcon);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setIcon(defaultIcon);
            }
        });
    }

    public static Clip sounddddd(String str) {
        //进入游戏时播放BGM
        //       Clip clip = null;
        try {
            clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/" + str + "-周杰伦.wav")));
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
            e.printStackTrace();
        }
        return clip;
    }


    private void addSoundControlButton() {
//        JButton musicbutton = new JButton();

        //给按钮设置默认背景颜色
        musicbutton.setIcon(defaultSoundIcon);
        //使按钮的字一直位于上方和中央
//        button.setVerticalTextPosition(SwingConstants.CENTER);
//        button.setHorizontalTextPosition(SwingConstants.CENTER);
        musicbutton.setLocation(WIDTH * 4 / 5, HEIGHT * 4 / 5);
        musicbutton.setSize(50, 50);
        //  button.setFont(new Font("Rockwell", Font.BOLD, 20));
        //  button.setBackground(Color.LIGHT_GRAY);
        add(musicbutton);

        sounddddd("最伟大的作品");

//        //进入游戏时播放BGM
//        try {
//            Clip clip = AudioSystem.getClip();
//            clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/最伟大的作品-周杰伦.wav")));
//            clip.loop(Clip.LOOP_CONTINUOUSLY);

            //加入鼠标监听；
            musicbutton.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {

                }

                @Override
                public void mousePressed(MouseEvent e) {
                    if (musicbutton.getIcon().equals(defaultSoundIcon)) {
                        musicbutton.setIcon(closeSoundIcon);
//                    try {
//
//                    } catch (LineUnavailableException ex) {
//                        throw new RuntimeException(ex);
//                    }
                        //clip.close();
                        clip.stop();
                    } else {
//                    try {
//                        Clip clip = AudioSystem.getClip();
//                        clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/20221126_022814转换格式.wav")));
//                        clip.loop(0);
//
//
//                        button.setIcon(defaultSoundIcon);
//                    } catch (LineUnavailableException | UnsupportedAudioFileException | IOException f) {
//                        f.printStackTrace();
                        clip.start();
                        musicbutton.setIcon(defaultSoundIcon);
                    }

                }

                @Override
                public void mouseReleased(MouseEvent e) {

                }

                @Override
                public void mouseEntered(MouseEvent e) {

                }

                @Override
                public void mouseExited(MouseEvent e) {

                }
            });

//        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
//            e.printStackTrace();
//        }

    }

    public static ChessGameFrame2 newgame() {
        ChessGameFrame2 mainFrame = new ChessGameFrame2(1024, 750);
        SwingUtilities.invokeLater(() -> {
            mainFrame.setVisible(true);
        });
//        SwingUtilities.invokeLater(() -> {
//            ChessGameFrame mainFrame = new ChessGameFrame(1024, 750);
//            mainFrame.setVisible(true);
//        });
        return mainFrame;
    }

    public ChessGameFrame2 getGameFrame() {
        return this;
    }

}
