package controller2;

import Level.Level;
import chessComponent2.SquareComponent2;
import model2.ChessColor;
import view2.ChessGameFrame2;
import view2.Chessboard2;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class AIController {
    int a;
    public void AIControl(Chessboard2 chessboard2) {
        ChessColor currentColor = chessboard2.getCurrentColor();
//        int preX = preStep.getX();
//        int preY = preStep.getY();result.add(canEat.get(i));
//                result.add(canBeEaten.get(i));
//                return result;
        SquareComponent2[][] board = chessboard2.getChessComponents();
//        SquareComponent chess1 = board[preX][preY-1];
//        SquareComponent chess2 = board[preX][preY+1];
//        SquareComponent chess3 = board[preX-1][preY];
//        SquareComponent chess4 = board[preX+1][preY+1];
        if (haveEat(chessboard2) != null) {
            SquareComponent2 first = haveEat(chessboard2).get(0);
            SquareComponent2 second = haveEat(chessboard2).get(1);
            if (first.getLevel() != Level.Pao) {
                chessboard2.swapChessComponents(first, second);
                ClickController2.AIonClick2(second, ChessGameFrame2.CB.clickController2);
                chessboard2.clickController2.swapPlayer();
                System.out.println("_____________________AI Nomal Eat____________________________");
            } else if (first.getLevel() == Level.Pao && first.getChessColor() == ChessColor.BLACK){
                chessboard2.Paoswap(first, second);
                ClickController2.AIonClick2(second, ChessGameFrame2.CB.clickController2);
                chessboard2.clickController2.swapPlayer();
                System.out.println("____________________AI Pao Eat_____________________________");
            }
        } else if (paoIsReversal(chessboard2).size() != 0)
            Label:{
                System.out.println("++++++++++++++++++AI Abnomal Move++++++++++++++++++++++++++++");
                for (SquareComponent2[] chessL : chessboard2.getChessComponents()) {
                    for (SquareComponent2 chess : chessL) {
                        if (PaoMove(paoIsReversal(chessboard2).get(0), chess, chessboard2.getChessComponents()) && !chess.isReversal()) {
                            chessboard2.Paoswap(paoIsReversal(chessboard2).get(0), chess);
                            ClickController2.AIonClick2(chess, ChessGameFrame2.CB.clickController2);
                            chessboard2.clickController2.swapPlayer();
                            System.out.println("+++++++++++++++++++AI Pao Redom Eat++++++++++++++++++++");
                            break Label;
                        } else if (paoIsReversal(chessboard2).size() == 2 && PaoMove(paoIsReversal(chessboard2).get(1), chess, chessboard2.getChessComponents()) && !chess.isReversal()) {
                            chessboard2.Paoswap(paoIsReversal(chessboard2).get(1), chess);
                            ClickController2.AIonClick2(chess, ChessGameFrame2.CB.clickController2);
                            chessboard2.clickController2.swapPlayer();
                            System.out.println("+++++++++++++++++++AI Pao Redom Eat++++++++++++++++++++");
                            break Label;
                        }
                    }
                }
                if (havaUnRes(chessboard2)) {
                    System.out.println("<<<<<<<<<<<<<<<<<<<<<AI Radom Uncover>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    while (true) {
                        Random random = new Random();
                        int i = random.nextInt(0, 8);
                        int j = random.nextInt(0, 4);
                        if (!board[i][j].isReversal && board[i][j].getLevel() != Level.Blank) {
                            board[i][j].setReversal(true);
                            System.out.printf("Yours\n", board[i][j].getChessboardPoint().getX(), board[i][j].getChessboardPoint().getY());
                            board[i][j].repaint();
                            chessboard2.clickController2.swapPlayer();
                            break Label;
                        }
                    }
                } else {
                    System.out.println("???????????????? AI Empty Move ????????????????????????????");
                    SquareComponent2 chass = haveEmpty(chessboard2);
                    ArrayList<SquareComponent2> empty = new ArrayList<>();
                    int n = getSur(chessboard2, chass).size();
                    Random random = new Random();
                    for (int i = 0; i < n; i++) {
                        if (getSur(chessboard2, chass).get(i).getLevel() == Level.Blank) {
                            empty.add(getSur(chessboard2, chass).get(i));
                        }
                    }
                    int Size = empty.size();
                    switch (random.nextInt(Size)) {
                        case 0 -> {
                            chessboard2.swapChessComponents(chass, empty.get(0));
                            ClickController2.AIonClick2(empty.get(0), ChessGameFrame2.CB.clickController2);
                            chessboard2.clickController2.swapPlayer();
                            break Label;
                        }
                        case 1 -> {
                            chessboard2.swapChessComponents(chass, empty.get(1));
                            ClickController2.AIonClick2(empty.get(1), ChessGameFrame2.CB.clickController2);
                            chessboard2.clickController2.swapPlayer();
                            break Label;
                        }
                        case 2 -> {
                            chessboard2.swapChessComponents(chass, empty.get(2));
                            ClickController2.AIonClick2(empty.get(2), ChessGameFrame2.CB.clickController2);
                            chessboard2.clickController2.swapPlayer();
                            break Label;
                        }
                        case 3 -> {
                            chessboard2.swapChessComponents(chass, empty.get(3));
                            ClickController2.AIonClick2(empty.get(3), ChessGameFrame2.CB.clickController2);
                            chessboard2.clickController2.swapPlayer();
                            break Label;
                        }
                    }
                }
            }
        else if(havaUnRes(chessboard2)){
            System.out.println("<<<<<<<<<<<<<<<<<<<<<AI Radom Uncover>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            while (true) {
                Random random = new Random();
                int i = random.nextInt(0, 8);
                int j = random.nextInt(0, 4);
                if (!board[i][j].isReversal && board[i][j].getLevel() != Level.Blank){
                    board[i][j].setReversal(true);
                    System.out.printf("Yours\n", board[i][j].getChessboardPoint().getX(), board[i][j].getChessboardPoint().getY());
                    board[i][j].repaint();
                    chessboard2.clickController2.swapPlayer();
                    break ;
                }
            }
        }
        else {
            System.out.println("???????????????? AI Empty Move ????????????????????????????");
            SquareComponent2 chass = haveEmpty(chessboard2);
            ArrayList<SquareComponent2> empty = new ArrayList<>();
            int n = getSur(chessboard2,chass).size();
            Random random = new Random();
            for (int i = 0; i < n; i++) {
                if (getSur(chessboard2,chass).get(i).getLevel() == Level.Blank){
                    empty.add(getSur(chessboard2,chass).get(i));
                }
            }
            int Size = empty.size();
            switch (random.nextInt(Size)){
                case 0 -> {
                    chessboard2.swapChessComponents(chass , empty.get(0));
                    ClickController2.AIonClick2(empty.get(0), ChessGameFrame2.CB.clickController2);
                    chessboard2.clickController2.swapPlayer();
                }
                case 1 -> {
                    chessboard2.swapChessComponents(chass , empty.get(1));
                    ClickController2.AIonClick2(empty.get(1), ChessGameFrame2.CB.clickController2);
                    chessboard2.clickController2.swapPlayer();
                }
                case 2 -> {
                    chessboard2.swapChessComponents(chass , empty.get(2));
                    ClickController2.AIonClick2(empty.get(2), ChessGameFrame2.CB.clickController2);
                    chessboard2.clickController2.swapPlayer();
                }
                case 3 -> {
                    chessboard2.swapChessComponents(chass , empty.get(3));
                    ClickController2.AIonClick2(empty.get(3), ChessGameFrame2.CB.clickController2);
                    chessboard2.clickController2.swapPlayer();
                }
            }
        }
    }
    public ArrayList<SquareComponent2> paoIsReversal(Chessboard2 chessboard2){
        ArrayList<SquareComponent2> arr = new ArrayList<>();
        SquareComponent2[][] components = chessboard2.getChessComponents();
        for (SquareComponent2[] chess : components){
            for (SquareComponent2 ches : chess){
                if(ches.getLevel() == Level.Pao && ches.isReversal() && ches.getChessColor() == ChessColor.BLACK){
                    arr.add(ches);
                }
            }
        }
        return arr;
    }

    public boolean havaUnRes(Chessboard2 chessboard2){
        SquareComponent2[][] sqs = chessboard2.getChessComponents();
        for(SquareComponent2[] sq : sqs){
            for (SquareComponent2 chess : sq){
                if (!chess.isReversal && chess.getLevel()!= Level.Blank){
                    return true;
                }
            }
        }
        return false;
    }

    public ArrayList<SquareComponent2> haveEat(Chessboard2 chessboard2) {
        ChessColor currentColor = chessboard2.getCurrentColor();
        SquareComponent2 chessComps[][] = chessboard2.getChessComponents();
        ArrayList<SquareComponent2> canBeEaten = new ArrayList<>();
        ArrayList<SquareComponent2> canEat = new ArrayList<>();
        ArrayList<SquareComponent2> result = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 4; j++) {
                if (chessComps[i][j].getLevel() != Level.Pao && chessComps[i][j].getChessColor() == currentColor && chessComps[i][j].isReversal ) {
                    if (i != 0 && canEat(chessComps[i][j], chessComps[i - 1][j], chessboard2) && chessComps[i - 1][j].getLevel() != Level.Blank) {
                        canBeEaten.add(chessComps[i - 1][j]);
                        canEat.add(chessComps[i][j]);
                    }
                    if (i != 7 && canEat(chessComps[i][j], chessComps[i + 1][j], chessboard2)&& chessComps[i + 1][j].getLevel() != Level.Blank) {
                        canBeEaten.add(chessComps[i + 1][j]);
                        canEat.add(chessComps[i][j]);
                    }
                    if (j != 0 && canEat(chessComps[i][j], chessComps[i][j - 1], chessboard2)&& chessComps[i][j-1].getLevel() != Level.Blank) {
                        canBeEaten.add(chessComps[i][j - 1]);
                        canEat.add(chessComps[i][j]);
                    }
                    if (j != 3 && canEat(chessComps[i][j], chessComps[i][j + 1], chessboard2)&& chessComps[i][j+1].getLevel() != Level.Blank) {
                        canBeEaten.add(chessComps[i][j + 1]);
                        canEat.add(chessComps[i][j]);
                    }
                } else if (chessComps[i][j].isReversal && chessComps[i][j].getLevel() == Level.Pao && chessComps[i][j].getChessColor() == ChessColor.BLACK){
                    for (SquareComponent2[] chessL : chessboard2.getChessComponents()){
                        for (SquareComponent2 chess2 : chessL){
                            if (PaoMove(chessComps[i][j],chess2, chessboard2.getChessComponents()) && chess2.isReversal()){
                                canBeEaten.add(chess2);
                                canEat.add(chessComps[i][j]);
                            }
                        }
                    }
                }
            }
        }
        int n = canBeEaten.size();
        for (int i = 0; i < n; i++) {
            int k = 0;
            int l = 0;
            for (int j = 0; j < n; j++) {
                if (levelCompare(canBeEaten.get(i).getLevel(), canBeEaten.get(j).getLevel()) && canBeEaten.get(i) != canBeEaten.get(j)) {
                    k++;
                }else if (levelCompare(canBeEaten.get(i).getLevel(), canBeEaten.get(j).getLevel()) && canBeEaten.get(i) == canBeEaten.get(j))
                    l++;
            }
            if (k == n - 1) {
                result.add(canEat.get(i));
                result.add(canBeEaten.get(i));
                return result;
            } else if (l > 2) {
                result.add(canEat.get(i));
                result.add(canBeEaten.get(i));
                return result;
            }
        }
        return null;
    }

    public SquareComponent2 haveEmpty (Chessboard2 chessboard2) {
        ChessColor currentColor = chessboard2.getCurrentColor();
        SquareComponent2 chessComps[][] = chessboard2.getChessComponents();
        ArrayList<SquareComponent2> canBeEaten = new ArrayList<>();
        ArrayList<SquareComponent2> canEat = new ArrayList<>();
        ArrayList<SquareComponent2> result = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 4; j++) {
                if (chessComps[i][j].getLevel() != Level.Pao && chessComps[i][j].getChessColor() == ChessColor.BLACK && chessComps[i][j].isReversal) {
                    if (i != 0 && chessComps[i - 1][j].getLevel() == Level.Blank) {
                        canEat.add(chessComps[i][j]);
                    }
                    else if (i != 7 && chessComps[i + 1][j].getLevel() == Level.Blank) {
                        canEat.add(chessComps[i][j]);
                    }
                    else if (j != 0 && chessComps[i][j - 1].getLevel() == Level.Blank) {
                        canEat.add(chessComps[i][j]);
                    }
                    else if (j != 3 && chessComps[i][j + 1].getLevel() == Level.Blank) {
                        canEat.add(chessComps[i][j]);
                    }
                }
            }
        }
        int n = canEat.size();
        for (SquareComponent2 c1 : canEat) {
            int k = 0;
            for (SquareComponent2 c2 : canEat){
                if (levelCompare(c1.getLevel(),c2.getLevel()) && c1 != c2){
                    k++;
                }
            }
            if (k == n-1){
                return c1;
            }
        }
        return null;
    }

    public boolean canEat(SquareComponent2 A, SquareComponent2 B, Chessboard2 chessboard2) {
        ChessColor color = chessboard2.getCurrentColor();
        Level a = A.getLevel();
        Level b = B.getLevel();
        if (A.canMoveTo(chessboard2.getChessComponents(), B.getChessboardPoint()) && A.getChessColor() == color && B.getChessColor() != color) {
            switch (a) {
                case Bing:
                    if (b == Level.Bing || b == Level.Jiang || b == Level.Blank) {
                        return true;
                    } else {
                        return false;
                    }
                case Ma:
                    if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Blank) {
                        return true;
                    } else {
                        return false;
                    }
                case Che:
                    if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Blank) {
                        return true;
                    } else {
                        return false;
                    }
                case Xiang:
                    if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Blank) {
                        return true;
                    } else {
                        return false;
                    }
                case Shi:
                    if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi || b == Level.Blank) {
                        return true;
                    } else {
                        return false;
                    }
                case Jiang:
                    //if (b == Level.Bing || b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi || b == Level.Jiang || b == Level.Blank) {
                    if (b == Level.Ma || b == Level.Pao || b == Level.Che || b == Level.Xiang || b == Level.Shi || b == Level.Jiang || b == Level.Blank) {
                        return true;
                    } else {
                        return false;
                    }
                case Pao:
                    if (b == Level.Blank) {
                        return false;
                    }
                    return true;
                default:
                    return false;
            }
        } else {
            return false;
        }
    }

    public boolean PaoMove(SquareComponent2 chess1, SquareComponent2 chess2, SquareComponent2[][] chessboard) {
        if (chess2.getLevel() == Level.Blank) {
            return false;
        }
        if (chess1.getChessColor() == chess2.getChessColor() && chess2.isReversal) {
            return false;
        }
        int x1 = chess1.chessboardPoint2.getX();
        int x2 = chess2.chessboardPoint2.getX();
        int y1 = chess1.chessboardPoint2.getY();
        int y2 = chess2.chessboardPoint2.getY();
        if (x1 == x2) {
            int theChessBetween = 0;
            for (int i = 1; i < Math.abs(y1 - y2); i++) {
                SquareComponent2 chessI = chessboard[x1][Math.min(y1, y2) + i];
                if (chessI.getLevel() != Level.Blank) {
                    theChessBetween++;
                }
            }
            return theChessBetween == 1;
        } else if (y1 == y2) {
            int theChessBetween = 0;
            for (int i = 1; i < Math.abs(x1 - x2); i++) {
                SquareComponent2 chessI = chessboard[Math.min(x1, x2) + i][y1];
                if (chessI.getLevel() != Level.Blank) {
                    theChessBetween++;
                }
            }
            return theChessBetween == 1;
        } else {
            return false;
        }
    }

    public Boolean levelCompare(Level A, Level B) {
        return A.num >= B.num;
    }
    public ArrayList<SquareComponent2> getSur (Chessboard2 chessboard2, SquareComponent2 first){
        SquareComponent2 sqs[][] = chessboard2.getChessComponents();
        ArrayList<SquareComponent2> re = new ArrayList<>();
        int x = first.chessboardPoint2.getX();
        int y = first.chessboardPoint2.getY();
        if (x > 0){
            re.add(sqs[x-1][y]);
        } if (x < 7) {
            re.add(sqs[x+1][y]);
        } if (y > 0) {
            re.add(sqs[x][y-1]);
        } if (y < 3) {
            re.add(sqs[x][y+1]);
        }
        return re;
    }

}

