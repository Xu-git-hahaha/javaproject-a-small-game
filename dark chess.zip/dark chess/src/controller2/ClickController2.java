
package controller2;

import Level.Level;
import chessComponent2.*;
import view2.ChessGameFrame2;
import view2.Chessboard2;
import model2.ChessColor;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

public class ClickController2 {
    public static int BlackPoint = 0;
    public static int RedPoint = 0;
    public static AIController ZhiZhangAI = new AIController();
    //public static int rev = 0;
    //public static int n = 1000;
    //public final Chessboard chessboard;
    public Chessboard2 chessboard2;
    private SquareComponent2 first;
    public static String winStr1;
    public static final Icon bche1 = new ImageIcon("resource/image/bche1.png");
    public static final Icon bche2 = new ImageIcon("resource/image/bche2.png");
    public static final Icon rche1 = new ImageIcon("resource/image/rche1.png");
    public static final Icon rche2 = new ImageIcon("resource/image/rche2.png");
    public static final Icon bma1 = new ImageIcon("resource/image/bma1.png");
    public static final Icon bma2 = new ImageIcon("resource/image/bma2.png");
    public static final Icon rma1 = new ImageIcon("resource/image/rma1.png");
    public static final Icon rma2 = new ImageIcon("resource/image/rma2.png");
    public static final Icon bpao1 = new ImageIcon("resource/image/bpao1.png");
    public static final Icon bpao2 = new ImageIcon("resource/image/bpao2.png");
    public static final Icon rpao1 = new ImageIcon("resource/image/rpao1.png");
    public static final Icon rpao2 = new ImageIcon("resource/image/rpao2.png");
    public static final Icon bshi1 = new ImageIcon("resource/image/bshi1.png");
    public static final Icon bshi2 = new ImageIcon("resource/image/bshi2.png");
    public static final Icon rshi1 = new ImageIcon("resource/image/rshi1.png");
    public static final Icon rshi2 = new ImageIcon("resource/image/rshi2.png");
    public static final Icon bbing1 = new ImageIcon("resource/image/bbing1.png");
    public static final Icon bbing2 = new ImageIcon("resource/image/bbing2.png");
    public static final Icon bbing3 = new ImageIcon("resource/image/bbing3.png");
    public static final Icon bbing4 = new ImageIcon("resource/image/bbing4.png");
    public static final Icon bbing5 = new ImageIcon("resource/image/bbing5.png");
    public static final Icon rbing1 = new ImageIcon("resource/image/rbing1.png");
    public static final Icon rbing2 = new ImageIcon("resource/image/rbing2.png");
    public static final Icon rbing3 = new ImageIcon("resource/image/rbing3.png");
    public static final Icon rbing4 = new ImageIcon("resource/image/rbing4.png");
    public static final Icon rbing5 = new ImageIcon("resource/image/rbing5.png");
    public static final Icon bxiang1 = new ImageIcon("resource/image/bxiang1.png");
    public static final Icon bxiang2 = new ImageIcon("resource/image/bxiang2.png");
    public static final Icon rxiang1 = new ImageIcon("resource/image/rxiang1.png");
    public static final Icon rxiang2= new ImageIcon("resource/image/rxiang2.png");
    public static final Icon bjiang1 = new ImageIcon("resource/image/bjiang1.png");
    public static final Icon rjiang1 = new ImageIcon("resource/image/rjiang1.png");

    public static int bbche = 0;
    public static int rrche = 0;
    public static int bbjiang = 0;
    public static int rrjiang = 0;
    public static int bbma = 0;
    public static int rrma = 0;
    public static int bbpao = 0;
    public static int rrpao = 0;
    public static int bbshi = 0;
    public static int rrshi = 0;
    public static int bbbing = 0;
    public static int rrbing = 0;
    public static int bbxiang = 0;
    public static int rrxiang = 0;

    public static JLabel jLabel1 = new JLabel();
    public static JLabel jLabel2 = new JLabel();
    public static JLabel jLabel3 = new JLabel();
    public static JLabel jLabel4 = new JLabel();
    public static JLabel jLabel5 = new JLabel();
    public static JLabel jLabel6 = new JLabel();
    public static JLabel jLabel7 = new JLabel();
    public static JLabel jLabel8 = new JLabel();
    public static JLabel jLabel9 = new JLabel();
    public static JLabel jLabel10 = new JLabel();
    public static JLabel jLabel11 = new JLabel();
    public static JLabel jLabel12 = new JLabel();
    public static JLabel jLabel13 = new JLabel();
    public static JLabel jLabel14 = new JLabel();

    public static void setEatenIndex() {
        bbche = 0;
        rrche = 0;
        bbjiang = 0;
        rrjiang = 0;
        bbma = 0;
        rrma = 0;
        bbpao = 0;
        rrpao = 0;
        bbshi = 0;
        rrshi = 0;
        bbbing = 0;
        rrbing = 0;
        bbxiang = 0;
        rrxiang = 0;
        jLabel1.setIcon(null);
        jLabel2.setIcon(null);
        jLabel3.setIcon(null);
        jLabel4.setIcon(null);
        jLabel5.setIcon(null);
        jLabel6.setIcon(null);
        jLabel7.setIcon(null);
        jLabel8.setIcon(null);
        jLabel9.setIcon(null);
        jLabel11.setIcon(null);
        jLabel12.setIcon(null);
        jLabel13.setIcon(null);
        jLabel14.setIcon(null);
        jLabel10.setIcon(null);
//        jLabel1.repaint();
//        jLabel2.repaint();
//        jLabel3.repaint();
//        jLabel4.repaint();
//        jLabel5.repaint();
//        jLabel6.repaint();
//        jLabel7.repaint();
//        jLabel8.repaint();
//        jLabel9.repaint();
//        jLabel11.repaint();
//        jLabel12.repaint();
//        jLabel13.repaint();
//        jLabel14.repaint();
//        jLabel10.repaint();
    }

    public ClickController2(Chessboard2 chessboard2) {
        this.chessboard2 = chessboard2;
    }

    public int getBlackPoint() {
        return BlackPoint;
    }

    public int getRedPoint() {
        return RedPoint;
    }

    /**
     * 这个方法用来结束游戏
     *
     * @param chessColor 获胜方的颜色
     */
    public static void endGame(ChessGameFrame2 CGF, ChessColor chessColor) {
        winStr1 = "-------------------------  " + chessColor.toString() + " Win！ --------------------------";
        JOptionPane.showMessageDialog(null, winStr1, "游戏结束", JOptionPane.PLAIN_MESSAGE);
        //int n = JOptionPane.showConfirmDialog(null,"是否进入下一局？","",JOptionPane.YES_NO_OPTION);
        //System.out.println(n);
        Object[] options = {"是", "退出游戏"};        //定义按钮上的文字
        int n1 = JOptionPane.showOptionDialog(null, "是否进入下一局？", "", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        if (n1 == 0) {
            //重开一局
//            for (int i = 0; i < Chessboard.squareComponents.length; i++) {//squareComponents.length = 8
//                for (int j = 0; j < Chessboard.squareComponents[i].length; j++) {//squareComponents[i].length = 4
//                    Chessboard.squareComponents[i][j].setVisible(false);
//
//                }
//            }
//            //            ChessGameFrame mainFrame = new ChessGameFrame(1024, 750);
//            //            mainFrame.setVisible(true);
//            Chessboard.init
//            ChessGameFrame.CGFFFF = ChessGameFrame.newgame();
//            CGF.dispatchEvent(new WindowEvent(CGF,WindowEvent.WINDOW_CLOSING) );
//            ChessGameFrame.CGFFF = ChessGameFrame.CGFFFF;
            //Chessboard.cleanChessOfBord();
            //   CGF.labelll.setText("Click to decide whose turn");
            ClickController2.setEatenIndex();
            //      ClickController.setEatenIndex();
            //      ClickController.setEatenIndex();
            ClickController2.BlackPoint = 0;
            ClickController2.RedPoint = 0;
            ChessGameFrame2.blackScoreLabel.setText("黑方AI：" + ClickController2.BlackPoint + "分");
            ChessGameFrame2.redScoreLabel.setText("红方：" + ClickController2.RedPoint + "分");
            ChessGameFrame2.CB.cleanChessOfBord();
            ChessGameFrame2.CB.initAllChessOnBoard();
            ChessGameFrame2.getStatusLabel().setText("Yours turn");
        } else {
            //退出游戏
            //setEatenIndex();
            CGF.dispatchEvent(new WindowEvent(CGF, WindowEvent.WINDOW_CLOSING));
        }
        //JOptionPane.showMessageDialog(this,winStr1);
        //  System.out.println("-----------"+ chessColor.toString() + " Win -----------");
    }

    /**
     * 这个方法用于检查并刷新分数
     *
     * @param squareComponent2 被吃的棋子
     */
    public void checkPoint(SquareComponent2 squareComponent2) {
        if (squareComponent2.getChessColor() == ChessColor.RED) {
            BlackPoint += squareComponent2.getLevel().getPoint();
            ChessGameFrame2.blackScoreLabel.setText("黑方AI：" + BlackPoint + "分");
            //System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>Black points:" + BlackPoint + "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
        }
        if (squareComponent2.getChessColor() == ChessColor.BLACK) {
            RedPoint += squareComponent2.getLevel().getPoint();
            ChessGameFrame2.redScoreLabel.setText("红方：" + RedPoint + "分");
            //System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>Red points:" + RedPoint + "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
        }
        if (BlackPoint >= 60) {
            endGame(ChessGameFrame2.CGFFF, ChessColor.BLACK);
        } else if (RedPoint >= 60) {
            endGame(ChessGameFrame2.CGFFF, ChessColor.RED);
        }
    }

    public static void rmethod(JLabel jLabel, Icon si, int index, int index2, int rr) {
        jLabel.setIcon(si);

        jLabel.setLocation(435 + index * rr, 85 + 68 * index2);
        jLabel.setSize(60, 60);
        ChessGameFrame2.CGFFF.getContentPane().add(jLabel);
        jLabel.repaint();
    }

    public static void bmethod(JLabel jLabel, Icon si, int index, int index2, int bb) {
        jLabel.setIcon(si);
        jLabel.setLocation(57 - 10 * bb, 85 + 68 * index2);
        jLabel.setSize(60, 60);
        ChessGameFrame2.CGFFF.getContentPane().add(jLabel);
        jLabel.repaint();
        bbche = bbche + 1;
    }

    public void onClick(SquareComponent2 squareComponent2){
        try { //播放声音
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/Click.wav")));
            clip.loop(0);
        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
            throw new RuntimeException(e);
        }

        //判断第一次点击
        if (first == null && squareComponent2.toString() != "________") {
            if (handleFirst(squareComponent2)) {
                squareComponent2.setSelected(true);
                first = squareComponent2;
                first.repaint();
            }
        } else if (first != null) {
            if (first == squareComponent2) { // 再次点击取消选取
                squareComponent2.setSelected(false);
                SquareComponent2 recordFirst = first;
                first = null;
                recordFirst.repaint();
            } else if ( handleSecond(squareComponent2)&& first.getLevel() != Level.Pao) {
                //repaint in swap chess method.
                if (chessboard2.swapChessComponents(first, squareComponent2)) {
                    chessboard2.clickController2.swapPlayer();
//                    try {
//                        Thread.sleep(1000*2);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
                    System.out.println(1);
                    System.out.println(2);
                    System.out.println(3);
                    System.out.println(4);
                    System.out.println(5);
                    ZhiZhangAI.AIControl(ChessGameFrame2.CB);
                    //checkPoint(squareComponent);
                    first.setSelected(false);
                    first = null;
                    if (!squareComponent2.toString().equals("________")) {
                        System.out.println(squareComponent2.toString() + "has been killed");

                        String getSubStr2 = squareComponent2.toString().substring(0, 7);
                        switch (getSubStr2) {
                            case "Che___B":
                                if (bbche == 0) {
                                    jLabel1.setIcon(bche1);
                                    jLabel1.setLocation(57 - 10 * bbche, 85);
                                    jLabel1.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel1);
                                    jLabel1.repaint();
                                    bbche = bbche + 1;
                                    break;
                                } else if (bbche == 1) {
                                    jLabel1.setIcon(bche2);
                                    jLabel1.setLocation(57 - 10 * bbche, 85);
                                    jLabel1.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel1);
                                    jLabel1.repaint();
                                    bbche = bbche + 1;
                                    break;
                                }
                            case "Che___R":
                                if(rrche == 0) {
                                    jLabel2.setIcon(rche1);
                                    jLabel2.setLocation(435 + 10 * rrche, 85);
                                    jLabel2.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel2);
                                    jLabel2.repaint();
                                    rrche = rrche + 1;
                                    break;
                                }else if(rrche ==1){
                                    jLabel2.setIcon(rche2);
                                    jLabel2.setLocation(435 + 10 * rrche, 85);
                                    jLabel2.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel2);
                                    jLabel2.repaint();
                                    rrche = rrche + 1;
                                    break;
                                }
                            case "Ma____B":
                                if(bbma == 0){
                                    jLabel4.setIcon(bma1);
                                    jLabel4.setLocation(57 - 10 * bbma, 85 + 68 * 1);
                                    jLabel4.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel4);
                                    jLabel4.repaint();
                                    bbma = bbma + 1;
                                    break;
                                } else if (bbma == 1) {
                                    jLabel4.setIcon(bma2);
                                    jLabel4.setLocation(57 - 10 * bbma, 85 + 68 * 1);
                                    jLabel4.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel4);
                                    jLabel4.repaint();
                                    bbma = bbma + 1;
                                    break;
                                }
                            case "Ma____R":
                                if(rrma == 0) {
                                    jLabel3.setIcon(rma1);
                                    jLabel3.setLocation(435 + 10 * rrma, 85 + 68 * 1);
                                    jLabel3.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel3);
                                    jLabel3.repaint();
                                    rrma = rrma + 1;
                                    break;
                                }else if (rrma == 1){
                                    jLabel3.setIcon(rma2);
                                    jLabel3.setLocation(435 + 10 * rrma, 85 + 68 * 1);
                                    jLabel3.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel3);
                                    jLabel3.repaint();
                                    rrma = rrma + 1;
                                    break;
                                }
                            case "Pao___B":
                                if(bbpao == 0) {
                                    jLabel5.setIcon(bpao1);
                                    jLabel5.setLocation(57 - 10 * bbpao, 85 + 68 * 2);
                                    jLabel5.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel5);
                                    jLabel5.repaint();
                                    bbpao = bbpao + 1;
                                    break;
                                }else if(bbpao == 1){
                                    jLabel5.setIcon(bpao2);
                                    jLabel5.setLocation(57 - 10 * bbpao, 85 + 68 * 2);
                                    jLabel5.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel5);
                                    jLabel5.repaint();
                                    bbpao = bbpao + 1;
                                    break;
                                }
                            case "Pao___R":
                                if(rrpao == 0) {
                                    jLabel6.setIcon(rpao1);
                                    jLabel6.setLocation(435 + 10 * rrpao, 85 + 68 * 2);
                                    jLabel6.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel6);
                                    jLabel6.repaint();
                                    rrpao = rrpao + 1;
                                    break;
                                }else if(rrpao == 1){
                                    jLabel6.setIcon(rpao2);
                                    jLabel6.setLocation(435 + 10 * rrpao, 85 + 68 * 2);
                                    jLabel6.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel6);
                                    jLabel6.repaint();
                                    rrpao = rrpao + 1;
                                    break;
                                }
                            case "Shi___B":
                                if(bbshi == 0) {
                                    jLabel7.setIcon(bshi1);
                                    jLabel7.setLocation(57 - 10 * bbshi, 85 + 68 * 3);
                                    jLabel7.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel7);
                                    jLabel7.repaint();
                                    bbshi = bbshi + 1;
                                    break;
                                }else if (bbshi == 1){
                                    jLabel7.setIcon(bshi2);
                                    jLabel7.setLocation(57 - 10 * bbshi, 85 + 68 * 3);
                                    jLabel7.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel7);
                                    jLabel7.repaint();
                                    bbshi = bbshi + 1;
                                    break;
                                }
                            case "Shi___R":
                                if(rrshi == 0) {
                                    jLabel8.setIcon(rshi1);
                                    jLabel8.setLocation(435 + 10 * rrshi, 85 + 68 * 3);
                                    jLabel8.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel8);
                                    jLabel8.repaint();
                                    rrshi = rrshi + 1;
                                    break;
                                }else if(rrshi == 1){
                                    jLabel8.setIcon(rshi2);
                                    jLabel8.setLocation(435 + 10 * rrshi, 85 + 68 * 3);
                                    jLabel8.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel8);
                                    jLabel8.repaint();
                                    rrshi = rrshi + 1;
                                    break;
                                }
                            case "Bing__B":
                                if(bbbing == 0) {
                                    jLabel9.setIcon(bbing1);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 1){
                                    jLabel9.setIcon(bbing2);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 2){
                                    jLabel9.setIcon(bbing3);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 3){
                                    jLabel9.setIcon(bbing4);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 4){
                                    jLabel9.setIcon(bbing5);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }
                            case "Bing__R":
                                if(rrbing == 0) {
                                    jLabel10.setIcon(rbing1);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 1){
                                    jLabel10.setIcon(rbing2);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 2){
                                    jLabel10.setIcon(rbing3);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 3){
                                    jLabel10.setIcon(rbing4);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 4){
                                    jLabel10.setIcon(rbing5);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }
                            case "Xiang_B":
                                if(bbxiang == 0) {
                                    jLabel11.setIcon(bxiang1);
                                    jLabel11.setLocation(57 - 10 * bbxiang, 85 + 68 * 5);
                                    jLabel11.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel11);
                                    jLabel11.repaint();
                                    bbxiang = bbxiang + 1;
                                    break;
                                }else if (bbxiang == 1){
                                    jLabel11.setIcon(bxiang2);
                                    jLabel11.setLocation(57 - 10 * bbxiang, 85 + 68 * 5);
                                    jLabel11.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel11);
                                    jLabel11.repaint();
                                    bbxiang = bbxiang + 1;
                                    break;
                                }
                            case "Xiang_R":
                                if(rrxiang == 0) {
                                    jLabel12.setIcon(rxiang1);
                                    jLabel12.setLocation(435 + 10 * rrxiang, 85 + 68 * 5);
                                    jLabel12.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel12);
                                    jLabel12.repaint();
                                    rrxiang = rrxiang + 1;
                                    break;
                                }else if (rrxiang == 1){
                                    jLabel12.setIcon(rxiang2);
                                    jLabel12.setLocation(435 + 10 * rrxiang, 85 + 68 * 5);
                                    jLabel12.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel12);
                                    jLabel12.repaint();
                                    rrxiang = rrxiang + 1;
                                    break;
                                }
                            case "Jiang_B":
                                jLabel13.setIcon(bjiang1);
                                jLabel13.setLocation(57 - 10 * bbjiang, 85 + 68 * 6);
                                jLabel13.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel13);
                                jLabel13.repaint();
                                bbjiang = bbjiang + 1;
                                break;
                            case "Jiang_R":
                                jLabel14.setIcon(rjiang1);
                                jLabel14.setLocation(435 + 10 * rrxiang, 85 + 68 * 6);
                                jLabel14.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel14);
                                jLabel14.repaint();
                                rrjiang = rrjiang + 1;
                                break;
                            case "_______":
                                System.out.println("111");
                                break;
                        }
//                        sc[i / 4][i % 4].repaint();
//                        sc[i / 4][i % 4].setVisible(true);
                    }
                    checkPoint(squareComponent2);
                }
                else{
                    System.out.println("eiugwetrhjrrthwhrehw45thrbaedsefrhnje5gawdegwa");
                    JOptionPane.showMessageDialog(null, "不可以这样移动哦~","Error", JOptionPane.PLAIN_MESSAGE);
                }
            } else if (first.getLevel() == Level.Pao) {
                if (PaoMove(first, squareComponent2, chessboard2.getChessComponents())) {
                    chessboard2.Paoswap(first, squareComponent2);
                    chessboard2.clickController2.swapPlayer();
//                    try {
//                        Thread.sleep(1000*2);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
                    System.out.println(1);
                    System.out.println(2);
                    System.out.println(3);
                    System.out.println(4);
                    System.out.println(5);
                    ZhiZhangAI.AIControl(ChessGameFrame2.CB);
                    //checkPoint(squareComponent);
                    first.setSelected(false);
                    first = null;
                    //swapPlayer();
                    System.out.println(squareComponent2.toString() + "has been killed");
                    String getSubStr2 = squareComponent2.toString().substring(0, 7);
                    switch (getSubStr2) {
                        case "Che___B":
                            if (bbche == 0) {
                                jLabel1.setIcon(bche1);
                                jLabel1.setLocation(57 - 10 * bbche, 85);
                                jLabel1.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel1);
                                jLabel1.repaint();
                                bbche = bbche + 1;
                                break;
                            } else if (bbche == 1) {
                                jLabel1.setIcon(bche2);
                                jLabel1.setLocation(57 - 10 * bbche, 85);
                                jLabel1.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel1);
                                jLabel1.repaint();
                                bbche = bbche + 1;
                                break;
                            }
                        case "Che___R":
                            if(rrche == 0) {
                                jLabel2.setIcon(rche1);
                                jLabel2.setLocation(435 + 10 * rrche, 85);
                                jLabel2.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel2);
                                jLabel2.repaint();
                                rrche = rrche + 1;
                                break;
                            }else if(rrche ==1){
                                jLabel2.setIcon(rche2);
                                jLabel2.setLocation(435 + 10 * rrche, 85);
                                jLabel2.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel2);
                                jLabel2.repaint();
                                rrche = rrche + 1;
                                break;
                            }
                        case "Ma____B":
                            if(bbma == 0){
                                jLabel4.setIcon(bma1);
                                jLabel4.setLocation(57 - 10 * bbma, 85 + 68 * 1);
                                jLabel4.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel4);
                                jLabel4.repaint();
                                bbma = bbma + 1;
                                break;
                            } else if (bbma == 1) {
                                jLabel4.setIcon(bma2);
                                jLabel4.setLocation(57 - 10 * bbma, 85 + 68 * 1);
                                jLabel4.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel4);
                                jLabel4.repaint();
                                bbma = bbma + 1;
                                break;
                            }
                        case "Ma____R":
                            if(rrma == 0) {
                                jLabel3.setIcon(rma1);
                                jLabel3.setLocation(435 + 10 * rrma, 85 + 68 * 1);
                                jLabel3.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel3);
                                jLabel3.repaint();
                                rrma = rrma + 1;
                                break;
                            }else if (rrma == 1){
                                jLabel3.setIcon(rma2);
                                jLabel3.setLocation(435 + 10 * rrma, 85 + 68 * 1);
                                jLabel3.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel3);
                                jLabel3.repaint();
                                rrma = rrma + 1;
                                break;
                            }
                        case "Pao___B":
                            if(bbpao == 0) {
                                jLabel5.setIcon(bpao1);
                                jLabel5.setLocation(57 - 10 * bbpao, 85 + 68 * 2);
                                jLabel5.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel5);
                                jLabel5.repaint();
                                bbpao = bbpao + 1;
                                break;
                            }else if(bbpao == 1){
                                jLabel5.setIcon(bpao2);
                                jLabel5.setLocation(57 - 10 * bbpao, 85 + 68 * 2);
                                jLabel5.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel5);
                                jLabel5.repaint();
                                bbpao = bbpao + 1;
                                break;
                            }
                        case "Pao___R":
                            if(rrpao == 0) {
                                jLabel6.setIcon(rpao1);
                                jLabel6.setLocation(435 + 10 * rrpao, 85 + 68 * 2);
                                jLabel6.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel6);
                                jLabel6.repaint();
                                rrpao = rrpao + 1;
                                break;
                            }else if(rrpao == 1){
                                jLabel6.setIcon(rpao2);
                                jLabel6.setLocation(435 + 10 * rrpao, 85 + 68 * 2);
                                jLabel6.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel6);
                                jLabel6.repaint();
                                rrpao = rrpao + 1;
                                break;
                            }
                        case "Shi___B":
                            if(bbshi == 0) {
                                jLabel7.setIcon(bshi1);
                                jLabel7.setLocation(57 - 10 * bbshi, 85 + 68 * 3);
                                jLabel7.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel7);
                                jLabel7.repaint();
                                bbshi = bbshi + 1;
                                break;
                            }else if (bbshi == 1){
                                jLabel7.setIcon(bshi2);
                                jLabel7.setLocation(57 - 10 * bbshi, 85 + 68 * 3);
                                jLabel7.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel7);
                                jLabel7.repaint();
                                bbshi = bbshi + 1;
                                break;
                            }
                        case "Shi___R":
                            if(rrshi == 0) {
                                jLabel8.setIcon(rshi1);
                                jLabel8.setLocation(435 + 10 * rrshi, 85 + 68 * 3);
                                jLabel8.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel8);
                                jLabel8.repaint();
                                rrshi = rrshi + 1;
                                break;
                            }else if(rrshi == 1){
                                jLabel8.setIcon(rshi2);
                                jLabel8.setLocation(435 + 10 * rrshi, 85 + 68 * 3);
                                jLabel8.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel8);
                                jLabel8.repaint();
                                rrshi = rrshi + 1;
                                break;
                            }
                        case "Bing__B":
                            if(bbbing == 0) {
                                jLabel9.setIcon(bbing1);
                                jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                jLabel9.repaint();
                                bbbing = bbbing + 1;
                                break;
                            }else if(bbbing == 1){
                                jLabel9.setIcon(bbing2);
                                jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                jLabel9.repaint();
                                bbbing = bbbing + 1;
                                break;
                            }else if(bbbing == 2){
                                jLabel9.setIcon(bbing3);
                                jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                jLabel9.repaint();
                                bbbing = bbbing + 1;
                                break;
                            }else if(bbbing == 3){
                                jLabel9.setIcon(bbing4);
                                jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                jLabel9.repaint();
                                bbbing = bbbing + 1;
                                break;
                            }else if(bbbing == 4){
                                jLabel9.setIcon(bbing5);
                                jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                jLabel9.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                jLabel9.repaint();
                                bbbing = bbbing + 1;
                                break;
                            }
                        case "Bing__R":
                            if(rrbing == 0) {
                                jLabel10.setIcon(rbing1);
                                jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                jLabel10.repaint();
                                rrbing = rrbing + 1;
                                break;
                            }else if(rrbing == 1){
                                jLabel10.setIcon(rbing2);
                                jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                jLabel10.repaint();
                                rrbing = rrbing + 1;
                                break;
                            }else if(rrbing == 2){
                                jLabel10.setIcon(rbing3);
                                jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                jLabel10.repaint();
                                rrbing = rrbing + 1;
                                break;
                            }else if(rrbing == 3){
                                jLabel10.setIcon(rbing4);
                                jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                jLabel10.repaint();
                                rrbing = rrbing + 1;
                                break;
                            }else if(rrbing == 4){
                                jLabel10.setIcon(rbing5);
                                jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                jLabel10.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                jLabel10.repaint();
                                rrbing = rrbing + 1;
                                break;
                            }
                        case "Xiang_B":
                            if(bbxiang == 0) {
                                jLabel11.setIcon(bxiang1);
                                jLabel11.setLocation(57 - 10 * bbxiang, 85 + 68 * 5);
                                jLabel11.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel11);
                                jLabel11.repaint();
                                bbxiang = bbxiang + 1;
                                break;
                            }else if (bbxiang == 1){
                                jLabel11.setIcon(bxiang2);
                                jLabel11.setLocation(57 - 10 * bbxiang, 85 + 68 * 5);
                                jLabel11.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel11);
                                jLabel11.repaint();
                                bbxiang = bbxiang + 1;
                                break;
                            }
                        case "Xiang_R":
                            if(rrxiang == 0) {
                                jLabel12.setIcon(rxiang1);
                                jLabel12.setLocation(435 + 10 * rrxiang, 85 + 68 * 5);
                                jLabel12.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel12);
                                jLabel12.repaint();
                                rrxiang = rrxiang + 1;
                                break;
                            }else if (rrxiang == 1){
                                jLabel12.setIcon(rxiang2);
                                jLabel12.setLocation(435 + 10 * rrxiang, 85 + 68 * 5);
                                jLabel12.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel12);
                                jLabel12.repaint();
                                rrxiang = rrxiang + 1;
                                break;
                            }
                        case "Jiang_B":
                            jLabel13.setIcon(bjiang1);
                            jLabel13.setLocation(57 - 10 * bbjiang, 85 + 68 * 6);
                            jLabel13.setSize(60, 60);
                            ChessGameFrame2.CGFFF.getContentPane().add(jLabel13);
                            jLabel13.repaint();
                            bbjiang = bbjiang + 1;
                            break;
                        case "Jiang_R":
                            jLabel14.setIcon(rjiang1);
                            jLabel14.setLocation(435 + 10 * rrxiang, 85 + 68 * 6);
                            jLabel14.setSize(60, 60);
                            ChessGameFrame2.CGFFF.getContentPane().add(jLabel14);
                            jLabel14.repaint();
                            rrjiang = rrjiang + 1;
                            break;
                        case "_______":
                            System.out.println("111");
                            break;
                    }
                    checkPoint(squareComponent2);
                }
                else{
                    System.out.println("eiugwetrhjrrthwhrehw45thrbaedsefrhnje5gawdegwa");
                    JOptionPane.showMessageDialog(null, "不可以这样移动哦~","Error", JOptionPane.PLAIN_MESSAGE);
                }
            } else if(!handleSecond(squareComponent2)&&  first.getLevel() != Level.Pao){
                    System.out.println("eiugwetrhjrrthwhrehw45thrbaedsefrhnje5gawdegwa");
                    JOptionPane.showMessageDialog(null, "不可以这样移动哦~","Error", JOptionPane.PLAIN_MESSAGE);

            }
        }
    }

    public static void AIonClick2(SquareComponent2 squareComponent2, ClickController2 clik) {
//        try { //播放声音
//            Clip clip = AudioSystem.getClip();
//            clip.open(AudioSystem.getAudioInputStream(new File("resource/sound/Click.wav")));
//            clip.loop(0);
//        } catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
//            throw new RuntimeException(e);
//        }

                    if (!squareComponent2.toString().equals("________")) {
                        System.out.println(squareComponent2.toString() + "has been killed");

                        String getSubStr2 = squareComponent2.toString().substring(0, 7);
                        switch (getSubStr2) {
                            case "Che___B":
                                if (bbche == 0) {
                                    jLabel1.setIcon(bche1);
                                    jLabel1.setLocation(57 - 10 * bbche, 85);
                                    jLabel1.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel1);
                                    jLabel1.repaint();
                                    bbche = bbche + 1;
                                    break;
                                } else if (bbche == 1) {
                                    jLabel1.setIcon(bche2);
                                    jLabel1.setLocation(57 - 10 * bbche, 85);
                                    jLabel1.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel1);
                                    jLabel1.repaint();
                                    bbche = bbche + 1;
                                    break;
                                }
                            case "Che___R":
                                if(rrche == 0) {
                                    jLabel2.setIcon(rche1);
                                    jLabel2.setLocation(435 + 10 * rrche, 85);
                                    jLabel2.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel2);
                                    jLabel2.repaint();
                                    rrche = rrche + 1;
                                    break;
                                }else if(rrche ==1){
                                    jLabel2.setIcon(rche2);
                                    jLabel2.setLocation(435 + 10 * rrche, 85);
                                    jLabel2.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel2);
                                    jLabel2.repaint();
                                    rrche = rrche + 1;
                                    break;
                                }
                            case "Ma____B":
                                if(bbma == 0){
                                    jLabel4.setIcon(bma1);
                                    jLabel4.setLocation(57 - 10 * bbma, 85 + 68 * 1);
                                    jLabel4.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel4);
                                    jLabel4.repaint();
                                    bbma = bbma + 1;
                                    break;
                                } else if (bbma == 1) {
                                    jLabel4.setIcon(bma2);
                                    jLabel4.setLocation(57 - 10 * bbma, 85 + 68 * 1);
                                    jLabel4.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel4);
                                    jLabel4.repaint();
                                    bbma = bbma + 1;
                                    break;
                                }
                            case "Ma____R":
                                if(rrma == 0) {
                                    jLabel3.setIcon(rma1);
                                    jLabel3.setLocation(435 + 10 * rrma, 85 + 68 * 1);
                                    jLabel3.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel3);
                                    jLabel3.repaint();
                                    rrma = rrma + 1;
                                    break;
                                }else if (rrma == 1){
                                    jLabel3.setIcon(rma2);
                                    jLabel3.setLocation(435 + 10 * rrma, 85 + 68 * 1);
                                    jLabel3.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel3);
                                    jLabel3.repaint();
                                    rrma = rrma + 1;
                                    break;
                                }
                            case "Pao___B":
                                if(bbpao == 0) {
                                    jLabel5.setIcon(bpao1);
                                    jLabel5.setLocation(57 - 10 * bbpao, 85 + 68 * 2);
                                    jLabel5.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel5);
                                    jLabel5.repaint();
                                    bbpao = bbpao + 1;
                                    break;
                                }else if(bbpao == 1){
                                    jLabel5.setIcon(bpao2);
                                    jLabel5.setLocation(57 - 10 * bbpao, 85 + 68 * 2);
                                    jLabel5.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel5);
                                    jLabel5.repaint();
                                    bbpao = bbpao + 1;
                                    break;
                                }
                            case "Pao___R":
                                if(rrpao == 0) {
                                    jLabel6.setIcon(rpao1);
                                    jLabel6.setLocation(435 + 10 * rrpao, 85 + 68 * 2);
                                    jLabel6.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel6);
                                    jLabel6.repaint();
                                    rrpao = rrpao + 1;
                                    break;
                                }else if(rrpao == 1){
                                    jLabel6.setIcon(rpao2);
                                    jLabel6.setLocation(435 + 10 * rrpao, 85 + 68 * 2);
                                    jLabel6.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel6);
                                    jLabel6.repaint();
                                    rrpao = rrpao + 1;
                                    break;
                                }
                            case "Shi___B":
                                if(bbshi == 0) {
                                    jLabel7.setIcon(bshi1);
                                    jLabel7.setLocation(57 - 10 * bbshi, 85 + 68 * 3);
                                    jLabel7.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel7);
                                    jLabel7.repaint();
                                    bbshi = bbshi + 1;
                                    break;
                                }else if (bbshi == 1){
                                    jLabel7.setIcon(bshi2);
                                    jLabel7.setLocation(57 - 10 * bbshi, 85 + 68 * 3);
                                    jLabel7.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel7);
                                    jLabel7.repaint();
                                    bbshi = bbshi + 1;
                                    break;
                                }
                            case "Shi___R":
                                if(rrshi == 0) {
                                    jLabel8.setIcon(rshi1);
                                    jLabel8.setLocation(435 + 10 * rrshi, 85 + 68 * 3);
                                    jLabel8.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel8);
                                    jLabel8.repaint();
                                    rrshi = rrshi + 1;
                                    break;
                                }else if(rrshi == 1){
                                    jLabel8.setIcon(rshi2);
                                    jLabel8.setLocation(435 + 10 * rrshi, 85 + 68 * 3);
                                    jLabel8.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel8);
                                    jLabel8.repaint();
                                    rrshi = rrshi + 1;
                                    break;
                                }
                            case "Bing__B":
                                if(bbbing == 0) {
                                    jLabel9.setIcon(bbing1);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 1){
                                    jLabel9.setIcon(bbing2);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 2){
                                    jLabel9.setIcon(bbing3);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 3){
                                    jLabel9.setIcon(bbing4);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }else if(bbbing == 4){
                                    jLabel9.setIcon(bbing5);
                                    jLabel9.setLocation(57 - 10 * bbbing, 85 + 68 * 4);
                                    jLabel9.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel9);
                                    jLabel9.repaint();
                                    bbbing = bbbing + 1;
                                    break;
                                }
                            case "Bing__R":
                                if(rrbing == 0) {
                                    jLabel10.setIcon(rbing1);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 1){
                                    jLabel10.setIcon(rbing2);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 2){
                                    jLabel10.setIcon(rbing3);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 3){
                                    jLabel10.setIcon(rbing4);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }else if(rrbing == 4){
                                    jLabel10.setIcon(rbing5);
                                    jLabel10.setLocation(435 + 10 * rrbing, 85 + 68 * 4);
                                    jLabel10.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel10);
                                    jLabel10.repaint();
                                    rrbing = rrbing + 1;
                                    break;
                                }
                            case "Xiang_B":
                                if(bbxiang == 0) {
                                    jLabel11.setIcon(bxiang1);
                                    jLabel11.setLocation(57 - 10 * bbxiang, 85 + 68 * 5);
                                    jLabel11.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel11);
                                    jLabel11.repaint();
                                    bbxiang = bbxiang + 1;
                                    break;
                                }else if (bbxiang == 1){
                                    jLabel11.setIcon(bxiang2);
                                    jLabel11.setLocation(57 - 10 * bbxiang, 85 + 68 * 5);
                                    jLabel11.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel11);
                                    jLabel11.repaint();
                                    bbxiang = bbxiang + 1;
                                    break;
                                }
                            case "Xiang_R":
                                if(rrxiang == 0) {
                                    jLabel12.setIcon(rxiang1);
                                    jLabel12.setLocation(435 + 10 * rrxiang, 85 + 68 * 5);
                                    jLabel12.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel12);
                                    jLabel12.repaint();
                                    rrxiang = rrxiang + 1;
                                    break;
                                }else if (rrxiang == 1){
                                    jLabel12.setIcon(rxiang2);
                                    jLabel12.setLocation(435 + 10 * rrxiang, 85 + 68 * 5);
                                    jLabel12.setSize(60, 60);
                                    ChessGameFrame2.CGFFF.getContentPane().add(jLabel12);
                                    jLabel12.repaint();
                                    rrxiang = rrxiang + 1;
                                    break;
                                }
                            case "Jiang_B":
                                jLabel13.setIcon(bjiang1);
                                jLabel13.setLocation(57 - 10 * bbjiang, 85 + 68 * 6);
                                jLabel13.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel13);
                                jLabel13.repaint();
                                bbjiang = bbjiang + 1;
                                break;
                            case "Jiang_R":
                                jLabel14.setIcon(rjiang1);
                                jLabel14.setLocation(435 + 10 * rrxiang, 85 + 68 * 6);
                                jLabel14.setSize(60, 60);
                                ChessGameFrame2.CGFFF.getContentPane().add(jLabel14);
                                jLabel14.repaint();
                                rrjiang = rrjiang + 1;
                                break;
                            case "_______":
                                System.out.println("111");
                                break;
                        }
                    }
                    clik.checkPoint(squareComponent2);
            }



    /**
     * 这个方法用于判断炮能否移动
     *
     * @param chess1     炮
     * @param chess2     被炮吃的棋子
     * @param chessboard 现在的期盼情况
     * @return 炮能否移动
     */
    public boolean PaoMove(SquareComponent2 chess1, SquareComponent2 chess2, SquareComponent2[][] chessboard) {
        if (chess2.getLevel() == Level.Blank) {
            return false;
        }
        if (chess1.getChessColor() == chess2.getChessColor() && chess2.isReversal) {
            return false;
        }
        int x1 = chess1.chessboardPoint2.getX();
        int x2 = chess2.chessboardPoint2.getX();
        int y1 = chess1.chessboardPoint2.getY();
        int y2 = chess2.chessboardPoint2.getY();
        if (x1 == x2) {
            int theChessBetween = 0;
            for (int i = 1; i < Math.abs(y1 - y2); i++) {
                SquareComponent2 chessI = chessboard[x1][Math.min(y1, y2) + i];
                if (chessI.getLevel() != Level.Blank) {
                    theChessBetween++;
                }
            }
            return theChessBetween == 1;
        } else if (y1 == y2) {
            int theChessBetween = 0;
            for (int i = 1; i < Math.abs(x1 - x2); i++) {
                SquareComponent2 chessI = chessboard[Math.min(x1, x2) + i][y1];
                if (chessI.getLevel() != Level.Blank) {
                    theChessBetween++;
                }
            }
            return theChessBetween == 1;
        } else {
            return false;
        }
    }

    public void enter(SquareComponent2 squareComponent2) {
        squareComponent2.setEntered(true);
        squareComponent2.repaint();
    }

    public void out(SquareComponent2 squareComponent2) {
        squareComponent2.setEntered(false);
        squareComponent2.repaint();
    }


    /**
     * @param squareComponent2 目标选取的棋子
     * @return 目标选取的棋子是否与棋盘记录的当前行棋方颜色相同
     */
    private boolean handleFirst(SquareComponent2 squareComponent2){
        if (!squareComponent2.isReversal()) {
            squareComponent2.setReversal(true);
            chessboard2.setCurrentColor(ChessColor.RED);
            System.out.printf("Yours\n", squareComponent2.getChessboardPoint().getX(), squareComponent2.getChessboardPoint().getY());
            squareComponent2.repaint();
            chessboard2.clickController2.swapPlayer();
//            try {
//                Thread.sleep(1000*2);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
            System.out.println(1);
            System.out.println(2);
            System.out.println(3);
            System.out.println(4);
            System.out.println(5);
            ZhiZhangAI.AIControl(ChessGameFrame2.CB);
//            try {
//                Thread.sleep(1000*2);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
            return false;
        }
        return squareComponent2.getChessColor() == chessboard2.getCurrentColor();
    }

    /**
     * @param squareComponent2 first棋子目标移动到的棋子second
     * @return first棋子是否能够移动到second棋子位置
     */
    private boolean handleSecond(SquareComponent2 squareComponent2) {
        //没翻开或空棋子，进入if
        if (!squareComponent2.isReversal()) {
            //没翻开且非空棋子不能走
            if (!(squareComponent2 instanceof EmptySlotComponent22)) {
                return false;
            }
        }


        System.out.println(first.toString());
        return squareComponent2.getChessColor() != chessboard2.getCurrentColor() &&
                first.canMoveTo(chessboard2.getChessComponents(), squareComponent2.getChessboardPoint());
    }

    public void swapPlayer() {
        chessboard2.setCurrentColor(chessboard2.getCurrentColor() == ChessColor.BLACK ? ChessColor.RED : ChessColor.BLACK);
        if(chessboard2.currentColor == ChessColor.RED) {
            ChessGameFrame2.getStatusLabel().setText(String.format("Yours TURN"));
            // ChessGameFrame.labelll.setText(String.format("%s's TURN", chessboard.currentColor));
        }else {
            ChessGameFrame2.getStatusLabel().setText(String.format("AI's TURN"));
        }
    }
}
